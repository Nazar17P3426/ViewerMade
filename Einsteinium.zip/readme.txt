███████╗██╗███╗░░██╗░██████╗████████╗███████╗██╗███╗░░██╗██╗██╗░░░██╗███╗░░░███╗
██╔════╝██║████╗░██║██╔════╝╚══██╔══╝██╔════╝██║████╗░██║██║██║░░░██║████╗░████║
█████╗░░██║██╔██╗██║╚█████╗░░░░██║░░░█████╗░░██║██╔██╗██║██║██║░░░██║██╔████╔██║
██╔══╝░░██║██║╚████║░╚═══██╗░░░██║░░░██╔══╝░░██║██║╚████║██║██║░░░██║██║╚██╔╝██║
███████╗██║██║░╚███║██████╔╝░░░██║░░░███████╗██║██║░╚███║██║╚██████╔╝██║░╚═╝░██║
╚══════╝╚═╝╚═╝░░╚══╝╚═════╝░░░░╚═╝░░░╚══════╝╚═╝╚═╝░░╚══╝╚═╝░╚═════╝░╚═╝░░░░░╚═╝

Created by Marlon2210 and N17Pro3426
If you don't know what this does, just don't test it!
This is a malware!
This works ONLY in Windows 7, 8, 8.1, 10 and 11
The GDI effects works properly in Windows 7 without the aero theme
It's very dangerous for the non-safety version
The non-safety will just corrupt the MBR, and such as Task Manager, Registry Editor, and Command Prompt will be disabled!
I'm NOT responsible for ANY damages!
Thanks to N17Pro3426 for helping me
































































Hi N17Pro3426, I am Wynn, GusttMalWare, pankoza, RainflowBoi, Comium92, yedb0y33k, fr4ctalz, EmmyMalware, and more!