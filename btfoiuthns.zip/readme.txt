btfoiuthns.exe by pankoza

C++ GDI Malware
This is very dangerous for the non-safety version, the non-safety version will damage the MBR and make the PC unusable
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy!
I'm not responsible for any damages.
Credits to ArTicZera and Wipet for the HSL RGBQUAD
Credits to ArTicZera and Rekto for the blur effect
Creation date: August 12 2023
This is probably my last malware, because starting next month I will be too busy with private life (School etc.)

Thanks to fr4ctalz for helping with the first payload and the first 3 bytebeats
Credits to N17Pro3426 for one bytebeat


This is my longest malware so far (16 payloads lasting ~8 minutes)



















































































hi fr4ctalz and N17Pro3426, if you are reading this, hi