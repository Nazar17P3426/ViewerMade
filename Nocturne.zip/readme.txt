Nocturne by @mrsuperbuddy8216 (I am lazy to do logo)
----------------------------------------------------
This is better version of noctur trojan
Language: C++
Thanks to: wipet, LowoTech(for last sound *secret: I remixed it*), pankoza
----------------------------------------------------
WARNING!!!
Running Nocturne without ".peaceful" branch, it will destroy your computer