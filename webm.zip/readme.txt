webm.exe by pankoza
a short malware developed the course of a few hours
the non-safety version will destroy your PC when you run it, I'm not responsible for any damages
Credits to ArTicZera and Wipet for the HSL
Credits to N17Pro3426 for the RndRGB COLORREF
Credits to fr4ctalz for the 1st bytebeat
creation date: October 24 2023 (a week before Halloween)
this malware contains flashing lights and earrape, not for epilepsy
If you want to run it on Windows XP/Server 2003 x64 Edition, then use the x64 version or it won't set itself as critical process



























































Hi fr4ctalz, N17Pro3426, Crypto NWO and RainflowBoi, if you are reading this, hi