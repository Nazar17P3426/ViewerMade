Questions:
you can ask me a question about this malware by commenting on https://www.youtube.com/watch?v=EUwWDzGezoA

Information:
Destructive: False
Testable: True (there is a small chance of crash)
Creation data: 11/16/2023
Similar malwares: Resolveshahrab.exe
Bugs: gmon.out (it's not called bug), fast crash (in a small chance)

Warning:
It contains loud sounds or may lags (lag only happens when you run it below 2.5GB RAM)

Note (IMPORTANT):
This is my last malware, there is a small chance of crash, so, if it crashed, then run it again
also, the fast crash only happens on the delay, it's Resolveshahrab.exe remake pankoza,
I have finally learned how to convert BitBlt RGBQUAD to a bouncing square, say good
bye to the season 2 of my malwares, opthalmologist was my last season 1 malware, but
this one is my last season 2 malware, you can go to "entire malware database 2.0.zip"
file to see all my season 2 malwares :)