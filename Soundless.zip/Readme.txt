█▀ █▀█ █░█ █▄░█ █▀▄ █░░ █▀▀ █▀ █▀
▄█ █▄█ █▄█ █░▀█ █▄▀ █▄▄ ██▄ ▄█ ▄█

A skidded malware made by Vistamations with the help of Tubercomiosis99.
It has NO sounds and it's safety.

Made in C++.
The icon is the muted speaker emoji from SerenityOS.

"It's really skidded?"
I left a comment in the source code that says it's skidded.