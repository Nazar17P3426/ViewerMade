Malware name: Gadolinium
Malware type: Trojan
Damage Rate: Destructive
Made in: C++
Made by: pankoza
creation date: 20 July 2022
Credits to GetMBR for the hue function

The Safety version is safe to run on a real Machine, but the Destructive version will disable your Task Manager and corrupt your MBR, so run it only on VM