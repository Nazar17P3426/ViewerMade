Malware Names: SpongebobNoSleep, HorrorBob4
Malware Type: Creepypasta Trojan
Damage Rate: Destructive
Made in: C#
Inspired by: MrsMajor 3.0
creator: pankoza
Credits: Gork3m/r00tabx for the MrsMajor 3.0 Source, FlyTech for the icon, CYBER SOLDIER for logonui overwriter

Warning! Do not run this on real pc! Creator not responsible for any damages! This trojan was created for fun, not to destroy real pc's