bcdef by @mrsuperbuddy8216 (last malware?)
-----------------------------------------------
Created on: C++
Thanks to: sohiel shahrab (for some payloads)
-----------------------------------------------
Warning!
Running non-peaceful version, it can destroy your computer