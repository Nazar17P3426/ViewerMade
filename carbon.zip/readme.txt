carbon.exe
A remake of Fizz by Tubercomiosis99

Also, it's skidded and safety.
This malware has undergone 1 alpha and 1 beta.

Programming language: C++
Created on: 16.08.2024