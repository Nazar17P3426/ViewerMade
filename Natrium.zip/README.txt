
 _   _       _        _                 
| \ | |     | |      (_)                
|  \| | __ _| |_ _ __ _ _   _ _ __ ___  
| . ` |/ _` | __| '__| | | | | '_ ` _ \ 
| |\  | (_| | |_| |  | | |_| | | | | | |
\_| \_/\__,_|\__|_|  |_|\__,_|_| |_| |_|
                                        
                                        
====================================================================================================================

This malware is made by youcannothackme7134/malwarecoder11. Its a pretty short, but destructive
malware, drawing beziers, lines, glitches, and many more.
Hope you like it.

NOTE: Do not run in a real pc, this has no warnings at all.


 _     _       _        
| |   (_)     | |       
| |    _ _ __ | | _____ 
| |   | | '_ \| |/ / __|
| |___| | | | |   <\__ \
\_____/_|_| |_|_|\_\___/

====================================================================================================================
Creator's youtube: https://www.youtube.com/channel/UCU97UBWGC-NDUcqXYQp6rgw/featured
Creator's video: https://www.youtube.com/watch?v=FNZEsg5Fzig