screensaver.pyw
rate: safety
type: malware / joke

you need python and pywin32