Malware Name: FakeCHKDSK
Malware Type: Trojan
Damage rate: Destructive
Made in: Batch, Delphi, NASM for mbr

The destructive version is made in delphi and WILL destroy your mbr
The joke version is made in batch and won't destroy the mbr