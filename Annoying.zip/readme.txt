Annoying.exe
My new malware!
It has 8 payloads!
This program is made only by me
The program is harmless, but laggy and can cause seizures!
Good luck! :D
----------------------------------------------------------------------