 ____   ____     ____   ____    ____   ____
/    | /    \   /    | /    \  /    | /    \ 
|    |/     /   |    |/     /  |    |/     / 
|          /    |          /   |          /
|          \    |          \   |          \
|    |\     \   |    |\     \  |    |\     \
|    | \     |  |    | \     | |    | \     |
|    |  |    |  |    |  |    | |    |  |    |
\____/  \____/  \____/  \____/ \____/  \____/

             -[ Created by GetMbr ]-

Password: getmbr

This software is not safe to run this on your real PC because its
a malware that can make your PC unusable by deleting hal.dll 
(only works on winXP and compability of it) and overwriting MBR. 
Also this show some Flashing scenes and some destructive payload happen,
also this have loud sounds, so if you uncomfortable to see or hearning this
just dont run this on your computer, anyways run this only on virtual machine 
or a vm, to prevent damage to your real PC
Download vmware: https://vmware.com

This malware is made using C++ on Visual Studio 2022
if you want to download it, this: https://visualstudio.microsoft.com/

Anyways the payloads is 15 (GDI's / Bytebeat's)

--------------------------------------------------------------------------
--------------------------------[NOTE]------------------------------------
--------------------------------------------------------------------------

For skidders please do not disassemble this malware. or you will reported as a 
skidder, skidder or skid means script-kiddie or stealing codes instead of
learning any programming languages. Please make your own programs and viruses
without skidding.

------------------------------ [ACCOUNTS]---------------------------------

Contact the creator on Discord: GetMbr#2137
Reddit: https://reddit.com/u/GetMbr/

-------------------------------==========----------------------------------

Anyways this is the last malware that is created on Windows 8.1 and this
readme is now created on Windows 10...

Thanks for reading!!

[Created in Philippines]