﻿╔════════════╗
║Tithesis.exe║
╚════════════╝
It's destructive? No.
Compatibility: Windows 7 and newer
Payloads: 7
This malware uses nothing, but only BitBlt! (idk why I made it, like this)
Seizure warning!
Time to make: Around 1 hour.
Creation date: 03/04/2024
Thanks for testing!
═════════════════════════════════════════════