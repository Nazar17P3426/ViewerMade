struct37.exe
rate: harmless
made by: that kid 101
you need python and pywin32

don't hate for this even tho, yes I did use vbscript, but I also used python and a custom .wav file with bytebeat
