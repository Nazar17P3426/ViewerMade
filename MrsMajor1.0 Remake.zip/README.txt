If you need a authorization key to activate the trojan, contact Finley Tech through E-mail or Discord

E-Mail: rusinsmarkuss9@gmail.com
Discord: markyxthreetuf

I am NOT responsible for ANY damages you did within' this trojan.