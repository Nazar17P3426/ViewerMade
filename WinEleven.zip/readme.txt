﻿ __      __.__              .__                             
/  \    /  \__| ____   ____ |  |   _______  __ ____   ____  
\   \/\/   /  |/    \_/ __ \|  | _/ __ \  \/ // __ \ /    \ 
 \        /|  |   |  \  ___/|  |_\  ___/\   /\  ___/|   |  \
  \__/\  / |__|___|  /\___  >____/\___  >\_/  \___  >___|  /
       \/          \/     \/          \/          \/     \/ 

[ENG]
Malware name: WinEleven.exe
Type: Destructive

Start in own risk, the creator (DeX2PM) NOT respons for any damage to PC. This malware
can kill the MBR and crash system malware can delete files. After start you can see GDI
effects (skid) and loud bytebeat sounds before effect malware starts an administrator rules
and close UAC (recommended start on a virtual machine).

[RUS]
Название вируса: WinEleven.exe
Тип: Деструктивный

Запуская вы рискуете потерять систему, файлы, MBR разработчик не в ответе за ЛЮБЫЕ проблемы
с системой. Вирус может убить систему вместе с MBR стереть файлы и все другое. После запуска,
вирус обходит защиту УАК и запускается с правами администратора после этого вы увидите GDI
эффекты и услышите Байтбит музыку (рекомендуется запускать на виртуальной машине).