This is a simple trojan made in c++ without gdi that will overwrite your mbr, set as critical process, show a msgbox saying that your pc is dead, and bsod your pc when you close it
Note: on Windows XP x64 you need to run the x64 version or critical process won't work and there will be no BSOD
There is no execution warning, run it only on VM
You need to run as admin for the trojan to work
created by pankoza in 2.05.2022