$$$$$$$\              $$\     $$\                           $$\                         
$$  __$$\             $$ |    $$ |                          \__|                        
$$ |  $$ |$$\   $$\ $$$$$$\   $$$$$$$\   $$$$$$\  $$$$$$$\  $$\ $$\   $$\ $$$$$$\$$$$\  
$$$$$$$  |$$ |  $$ |\_$$  _|  $$  __$$\ $$  __$$\ $$  __$$\ $$ |$$ |  $$ |$$  _$$  _$$\ 
$$  __$$< $$ |  $$ |  $$ |    $$ |  $$ |$$$$$$$$ |$$ |  $$ |$$ |$$ |  $$ |$$ / $$ / $$ |
$$ |  $$ |$$ |  $$ |  $$ |$$\ $$ |  $$ |$$   ____|$$ |  $$ |$$ |$$ |  $$ |$$ | $$ | $$ |
$$ |  $$ |\$$$$$$  |  \$$$$  |$$ |  $$ |\$$$$$$$\ $$ |  $$ |$$ |\$$$$$$  |$$ | $$ | $$ |
\__|  \__| \______/    \____/ \__|  \__| \_______|\__|  \__|\__| \______/ \__| \__| \__|
                                                                                        

Ruthenium.exe

Coded by ReClean Bfresher
Help: NoFileFound

MBR Overwrite, some destruction, gdi payloads: C++

MBR: FASM

The author is not responsible for the damage to your computer, this Trojan overwrite the MBR (Master Boot Record) and deletes the system file, all with soundtrack and epileptic effects. If you are an epileptic, or you feel bad from flashing pictures, do not run this program.
Test the program EXCLUSIVELY on a virtual machine! The Trojan works best on Windows XP x32