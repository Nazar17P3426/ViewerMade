 ____  _________    __________  ___________  ______________  ___             ______________  ___________
/    \/         \  /          \/    _______\/     _____    \/   \           /              \/           \
|      _____     \|    ____    |   /        |    [     ]   |    |           \____     _____/|    ____    |
|     /     \     \   /    \   |   |   _____|    [_____]   |    |                |   |      |   |    \   |
|    |       |    |   |    |   |   |  |_    |     ____     |    |                |   |      |   |     |  |
|    |       |    |   \____/   |   \___|    |    /    \    |    \__________  ____|   |____  |   |____/   |
|    |       |    |            |            /    |    |    |               \/             \ |            |
\____/       \____/\__________/ \__________/\____/    \____/\______________/\_____________/ \___________/

-----------------------------------------[ By GetMbr ]-----------------------------------------------------

Password: getmbr
----------------
Ok, this program is dangerous that will destroy your bootloader by overwriting 512 bytes of random data.
And also my first PRGBQUAD malware ever and i learned by ms docs on 3 days also learning CreateDIBSection
function, also thanks for AG5516 for the PRGBQUAD def. 

This program can show messageboxes in start and end of the payloads (i mean before starting payloads the
messageboxes will show first also after payloads the messageboxes will be shown too.) also it can move 
windows on a random position using MoveWindow, and the clicks is very easy too.

I made this trojan for 6 days and it was painful of work for learning CreateDIBSection and i use RGBQUAD* 
struct instead of PRGBQAUD and again thanks for AG5516 for the PRGBQUAD def. 

but its has only 8 gdi payloads 4 destructive payloads.

++=========================================================================================++
NOTE: This program is for educational purposes only. And the creator is not any responsible
to destroy your computer with this trojan!

Thanks for reading......