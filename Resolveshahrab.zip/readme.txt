RES0LVEy#)SHAHR*&#^AB.exe 3y S0h3il shahr3?

Note:
This is made by soheil shahrab, I didn't have time to make full
readme, also the malware is short, you can make the 2.0 version
yourself, if you wan't to test it then make your own 2.0 version
made in 11/3/2023

Note only for pankoza and fr4ctalz:
but if you're pankoza or fr4ctalz, then you have to make collab
malware with me, ok? accept it pankoza :( or else you doomed