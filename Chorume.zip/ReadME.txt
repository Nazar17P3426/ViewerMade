 ██████╗██╗  ██╗ ██████╗ ██████╗ ██╗   ██╗███╗   ███╗███████╗
██╔════╝██║  ██║██╔═══██╗██╔══██╗██║   ██║████╗ ████║██╔════╝
██║     ███████║██║   ██║██████╔╝██║   ██║██╔████╔██║█████╗  
██║     ██╔══██║██║   ██║██╔══██╗██║   ██║██║╚██╔╝██║██╔══╝  
╚██████╗██║  ██║╚██████╔╝██║  ██║╚██████╔╝██║ ╚═╝ ██║███████╗
 ╚═════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝
------------------------------------------------------------------------------------------------
What is Chorume.exe?

Chorume.exe is a trojan that has 44 payloads, incluiding GDI-Effects and Bytebeats. This trojan was made in C++ 
and this is my 2nd GDI-Trojan, it overwrites the bootsector (MBR) to a Atari Breakout game (but this part is skidded, 
i'm sorry about that).
------------------------------------------------------------------------------------------------
Important!!!

If you want to run it use a Virtual Machine (I recommend Windows XP) or a Sandbox. Remembering that i'm not responsible 
for any damages to your machine. This malware shows flashing lights and loud sounds, so if you have a photosensitive 
disease like epilepsy, don't run this or watch any video about it for your security. And yes, i know that some payloads 
of this malware is skidded (just 1 payloads + 3 bytebeats + MBR) but it's just a bit so please try to ignore it...
------------------------------------------------------------------------------------------------
What is the difference about ChorumeDestructive and ChorumeSafe?

As the name says, ChorumeDestructive is the version that includes the destruction. Overwriting the bootsector (MBR) to
the Atari Breakout Game. This version is recommended just for people that uses Virtual Machine or a Sandbox. 
 
ChorumeSafe is the version that doesn't have the destruction. So it won't overwrite the (MBR) and you don't need to run
it on a Virtual Machine or a Sandbox. Just choose your preference...
------------------------------------------------------------------------------------------------
How do I play the MBR game?

Shift - Start game  
Ctrl  - Move to Left  
Alt   - Move to Right  
------------------------------------------------------------------------------------------------
Credits:

Rekto - Helped me a lot with GDI, thank you so much <3!  
Nanochess - Made the Atari Breakout Bootsector game. (Original link: https://github.com/nanochess/bricks)  
Viznut - Made 3 bytebeats that i used in Chorume.exe  
And thanks to whoever is reading this :3 
------------------------------------------------------------------------------------------------
Chorume Showcase:

JhoPro (me) - https://www.youtube.com/watch?v=RrCFQ8XtJK8
------------------------------------------------------------------------------------------------
Thanks for reading it <3