______       _           _                 
|  _  \     | |         (_)                
| | | |_   _| |__  _ __  _ _   _ _ __ ___  
| | | | | | | '_ \| '_ \| | | | | '_ ` _ \ 
| |/ /| |_| | |_) | | | | | |_| | | | | | |
|___/  \__,_|_.__/|_| |_|_|\__,_|_| |_| |_|
                                           
A new GDI malware by yedboy33k.
This malware can delete hal.dll, I'm NOT responsible for the damage!
Run it ONLY in a VM.
The harmless version is safe to run in a real PC.