this is a GDI malware
password is 123
you need python and pywin32