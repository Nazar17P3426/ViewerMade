  ______     ____             __       _   _ ___ __         
 |__  / |__ |___ \ _ __ ___  / _|_   _| \ | |_ _/ /_  _ __  
   / /| '_ \  __) | '_ ` _ \| |_| | | |  \| || | '_ \| '_ \ 
  / /_| | | |/ __/| | | | | |  _| |_| | |\  || | (_) | | | |
 /____|_| |_|_____|_| |_| |_|_|  \__,_|_| \_|___\___/|_| |_|
                                                            
Created by: pankoza

This is a simple trojan made in C++ and AutoHotKey that will overwrite MBR, spam programs and do a crazy window effect.
This will overwrite the MBR, so, run only on VM and I'm not responsible for any damages.