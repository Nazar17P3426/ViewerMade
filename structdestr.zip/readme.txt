███████╗████████╗██████╗ ██╗   ██╗ ██████╗████████╗██████╗ ███████╗███████╗████████╗██████╗ 
██╔════╝╚══██╔══╝██╔══██╗██║   ██║██╔════╝╚══██╔══╝██╔══██╗██╔════╝██╔════╝╚══██╔══╝██╔══██╗
███████╗   ██║   ██████╔╝██║   ██║██║        ██║   ██║  ██║█████╗  ███████╗   ██║   ██████╔╝
╚════██║   ██║   ██╔══██╗██║   ██║██║        ██║   ██║  ██║██╔══╝  ╚════██║   ██║   ██╔══██╗
███████║   ██║   ██║  ██║╚██████╔╝╚██████╗   ██║   ██████╔╝███████╗███████║   ██║   ██║  ██║
╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝  ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝
Malware name: Structdestr.exe
Made in: C++, nasm
Damage rate: Destructive+
Made by: pankoza
Creation date: 29.06.2022

You must have the .wav audio files in the directory with the Malware .exe or some sounds won't play
This malware is very dangerous, in addition to overwriting MBR and the first 32 KB of the Hard Drive, this malware can also disable task manager and unmount drives from a: to e:
This Malware is made for educational and entertainment purposes only, i'm not responsible for any damages, always run it in a Virtual Machine (VirtualBox, VMware, Hyper-V, Parallels, Windows Sandbox, qemu etc.)
