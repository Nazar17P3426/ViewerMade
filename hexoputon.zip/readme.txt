 _   _  ____  _  _  _____  ____  __  __  ____  _____  _  _    ____  _  _  ____ 
( )_( )( ___)( \/ )(  _  )(  _ \(  )(  )(_  _)(  _  )( \( )  ( ___)( \/ )( ___)
 ) _ (  )__)  )  (  )(_)(  )___/ )(__)(   )(   )(_)(  )  (    )__)  )  (  )__) 
(_) (_)(____)(_/\_)(_____)(__)  (______) (__) (_____)(_)\_)()(____)(_/\_)(____)

Made in: 1 week
Made by: WARLOKK28

Info from WARLOKK28:
Hi, if you're reading this, then you downloaded my GDI malware called
"hexoputon.exe". There are 2 versions of this malware: safe and unsafe,
and by the way, use windows xp x64 with screen resolution 1920 x 1080
or it will just close and not destroy your system :3

Have a good test!