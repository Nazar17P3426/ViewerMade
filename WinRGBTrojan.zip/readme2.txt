This is a clean version of WinRGB, this will not damage your PC
made by pankoza