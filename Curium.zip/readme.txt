░█████╗░██╗░░░██╗██████╗░██╗██╗░░░██╗███╗░░░███╗
██╔══██╗██║░░░██║██╔══██╗██║██║░░░██║████╗░████║
██║░░╚═╝██║░░░██║██████╔╝██║██║░░░██║██╔████╔██║
██║░░██╗██║░░░██║██╔══██╗██║██║░░░██║██║╚██╔╝██║
╚█████╔╝╚██████╔╝██║░░██║██║╚██████╔╝██║░╚═╝░██║
░╚════╝░░╚═════╝░╚═╝░░╚═╝╚═╝░╚═════╝░╚═╝░░░░░╚═╝
Created by Marlon2210 and N17Pro3426
This software is a malware
It's very dangerous for the non-safety version
The non-safety version will corrupt the MBR
This works in Windows 7, 8, 8.1, 10, 11
The GDI effects works best in Windows 7
I'm NOT responsible for ANY damages made using this software!
Thanks to N17Pro3426 for helping me

























































































































Hi EmmyMalware, yedb0y33k, Comium92, DxDiagDoge4407, pankoza, fr4ctalz, N17Pro3426, RainflowBoi, GusttMalWare, I am Wynn, and more!