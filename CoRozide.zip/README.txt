Hello there!

Seems you got a hold of my virus.
Well, if you have this software then I must know you.
If NOT, you are dead to me >:(
I created this virus 100% myself, but DeepFreeze helped with the Hard Drive wiper.
-------------------------------------------------------------------------------------------
CoRozide was created in C# originally, but I ended up converting it to C++ instead
to make it easier. About 60% of the GDI and sounds were originally C#. The virus
was programmed ONLY for educational and entertainment purposes. This virus
works on other OS's aswell, but has a surprise if it's NOT just Windows XP.
-------------------------------------------------------------------------------------------
Run this software ONLY on Windows XP 32-bit, if you just want the Graphical and
beauty of it's power. If you want to see special payloads, then run it on Windows 7
and above. Thank you :)
--------------------------------
Credits to my friends: ArTicZera, mr. virus, viruscheck, Dark-Tik, Exlon, DeepFreeze,
CorXnull, Carrot, NoFileFound and Itzsten.

P.S: This virus is highly inspired from nikitpad's trojans!

L00k f04 1he 3as1er 3gg2