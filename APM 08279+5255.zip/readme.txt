 █████╗ ██████╗ ███╗   ███╗     ██████╗  █████╗ ██████╗ ███████╗ █████╗ ███████╗██████╗ ███████╗███████╗   ███████╗██╗  ██╗███████╗
██╔══██╗██╔══██╗████╗ ████║    ██╔═████╗██╔══██╗╚════██╗╚════██║██╔══██╗██╔════╝╚════██╗██╔════╝██╔════╝   ██╔════╝╚██╗██╔╝██╔════╝
███████║██████╔╝██╔████╔██║    ██║██╔██║╚█████╔╝ █████╔╝    ██╔╝╚██████║███████╗ █████╔╝███████╗███████╗   █████╗   ╚███╔╝ █████╗  
██╔══██║██╔═══╝ ██║╚██╔╝██║    ████╔╝██║██╔══██╗██╔═══╝    ██╔╝  ╚═══██║╚════██║██╔═══╝ ╚════██║╚════██║   ██╔══╝   ██╔██╗ ██╔══╝  
██║  ██║██║     ██║ ╚═╝ ██║    ╚██████╔╝╚█████╔╝███████╗   ██║   █████╔╝███████║███████╗███████║███████║██╗███████╗██╔╝ ██╗███████╗
╚═╝  ╚═╝╚═╝     ╚═╝     ╚═╝     ╚═════╝  ╚════╝ ╚══════╝   ╚═╝   ╚════╝ ╚══════╝╚══════╝╚══════╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                                                                                                                  
APM 08279+5255.exe by pan koza 2
A 25 payload malware I worked on for over a month!
The non-safety version will destroy your PC when you run it, I'm not responsible for any damages, because this malware was created for educational purposes only!
Credits to EthernalVortex for the PRGBQUAD system
Credits to ArTicZera and Wipet for the HSL
Credits to GetMBR for the Hue function
Credits to fr4ctalz and N17Pro3426 for some effects
Creation time: November 6 2023 - December 16 2023
As always this malware contains flashing lights and earrape, not for epilepsy
If you want to run it on Windows XP/Server 2003 x64 Edition, then use the x64 version or it won't set itself as critical process
Recommended OS: Windows XP/Server 2003 x64 Edition (on x86 it might lag and bytebeats stop due to effect overload)
HUGE thanks to ArTicZera/JhoPro for the 3D cube base (from GDI-Worm.Win32.Purgatorium, I modified it to use cursors instead of icons for a unique effect)
Credits to fr4ctalz for making the icon
This is probably my last malware, because the GDI malwares are getting old and boring already and I'm tired of skidders stealing my code
MBR code from: https://github.com/littleli/boot2plasma



















































































Hi fr4ctalz, N17Pro3426, Crypto NWO and RainflowBoi, if you are reading this, hi,
and I can't believe it is nearly the end of the year 2023 and start of 2024!
(Good old 000.exe will be soon 9 years old)!