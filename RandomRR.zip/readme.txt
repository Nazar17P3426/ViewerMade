The safety malware, but it's randomized (2.0 shit is a big file again, I accidentally added iostream for bytebeats, I am clearly stupid why I do that?)
So, as you heard, it's private, you have to get permission from me to get the malware.

Date release 1.0: 7/30/2023
Date release 2.0: 7/31/2023

(I don't think so that the dates are correct or no, it's made before 2,3,7,8-Tetrachlorodibenzodioxin by pankoza)

pankoza, if you are reading this, why some of your ideas are same as mine like my HSLPHONE.exe colorful circle before your 3c436gr7je? and this malware with the idea of the circle on cursor like yours 2,3,7,8-Tetrachlorodibenzodioxin, but with a squares and a different like code?