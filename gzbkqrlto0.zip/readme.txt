gzbkqrlto0.exe by pankoza
This is a Malware
Works in Windows XP - 11
I'm not responsible for any damage, even physical damage
Don't run it if you have epilepsy
This is very Dangerous for the non-safety version. The non-safety version will overwrite the MBR and make it unusable
Credits to EthernalVortex for PRGBQUAD and credits to GetMBR/Void_ for Hue Function