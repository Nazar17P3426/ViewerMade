██╗░░░░░░█████╗░███╗░░██╗████████╗██╗░░██╗░█████╗░███╗░░██╗██╗░░░██╗███╗░░░███╗
██║░░░░░██╔══██╗████╗░██║╚══██╔══╝██║░░██║██╔══██╗████╗░██║██║░░░██║████╗░████║
██║░░░░░███████║██╔██╗██║░░░██║░░░███████║███████║██╔██╗██║██║░░░██║██╔████╔██║
██║░░░░░██╔══██║██║╚████║░░░██║░░░██╔══██║██╔══██║██║╚████║██║░░░██║██║╚██╔╝██║
███████╗██║░░██║██║░╚███║░░░██║░░░██║░░██║██║░░██║██║░╚███║╚██████╔╝██║░╚═╝░██║
╚══════╝╚═╝░░╚═╝╚═╝░░╚══╝░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝░╚═════╝░╚═╝░░░░░╚═╝

Created by Marlon2210
Programming language: C++
Destructive: Yes
This software is a malware
It's very dangerous for the non-safety version
This malware will overwrite the MBR,
I'm NOT responsible for ANY damages made using this malware.







































































Hi N17Pro3426, Comium92, MrDoge877, pankoza, yedb0y33k, fr4ctalz, RainflowBoi, I am Wynn, GusttMalWare, and more!