 _______  ___      _______        _______  __   __  _______ 
|       ||   |    |       |      |       ||  |_|  ||       |
|___    ||   |___ |____   |      |    ___||       ||    ___|
 ___|   ||    _  | ____|  |      |   |___ |       ||   |___ 
|___    ||   | | || ______| ___  |    ___| |     | |    ___|
 ___|   ||   |_| || |_____ |   | |   |___ |   _   ||   |___ 
|_______||_______||_______||___| |_______||__| |__||_______|

Finally I finished this malware.
Created in C++.
Payloads: 4
This malware can delete Registry and disable Task Manager.
I'm NOT responsible for ANY damages!
Run this ONLY in VM.