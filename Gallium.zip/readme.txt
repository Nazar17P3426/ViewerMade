░██████╗░░█████╗░██╗░░░░░██╗░░░░░██╗██╗░░░██╗███╗░░░███╗
██╔════╝░██╔══██╗██║░░░░░██║░░░░░██║██║░░░██║████╗░████║
██║░░██╗░███████║██║░░░░░██║░░░░░██║██║░░░██║██╔████╔██║
██║░░╚██╗██╔══██║██║░░░░░██║░░░░░██║██║░░░██║██║╚██╔╝██║
╚██████╔╝██║░░██║███████╗███████╗██║╚██████╔╝██║░╚═╝░██║
░╚═════╝░╚═╝░░╚═╝╚══════╝╚══════╝╚═╝░╚═════╝░╚═╝░░░░░╚═╝
Created by Marlon2210 and N17Pro3426
This malware will harm your computer!
It's very dangerous for the non-safety version
The non-safety version will overwrite the MBR
This works in Windows 7, 8, 8.1, 10 and 11
The GDI effects works properly in Windows 7 without the aero theme
I'm NOT responsible for ANY damages made using this software
Credits to TheRealMurban for some bytebeats
Thanks to N17Pro3426 for helping me







































































Hi fr4ctalz, pankoza, RainflowBoi, N17Pro3426, GusttMalWare, Comium92, EmmyMarlon, yedb0y33k, I am Wynn, and more!