olthaltlzpz.exe by pankoza (version 1.01)

C++ GDI Malware
This is very dangerous for the non-safety version, the non-safety version will damage the MBR, registry and make the PC unusable
on Windows Vista and newer it will also corrupt Boot\BCD
Works on Windows XP-11 but especially well on XP, Vista and 7
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy!
I'm not responsible for any damages.
Credits to ArTicZera and Wipet for the HSL RGBQUAD
Credits to ArTicZera and Rekto for the blur effect
Credits to GetMBR for the Hue Function (used for the bouncing rounded corner square)
Creation date: September 12 2023 (1.0), September 16 2023 (1.01)
I managed to make a comeback and will probably keep making malwares until the end of this year in my free time

Thanks to fr4ctalz for helping with some payloads
Credits to N17Pro3426 for some bytebeats

Bugs: bytebeat might stop on Windows XP halfway through the payloads
Version 1.01 changes: used the proper bytebeat in the last payload, and replaced the rounded square with shaking on the last payload as well as slightly modified the shader, also changed the shader in the 13th payload

Recommended Screen Resolutions: 1920x1080, 1440x900, 1280x720, 1024x768 or 800x600 due to the use of PRGBTRIPLE



















fun fact: olthaltlzpz is a Caesar Cipher for Hematemesis (a vomiting of blood)



























Hi fr4ctalz, N17Pro3426, RainflowBoi and Crypto NWO, if you are reading this, hi






























MBR is Windows 7 Koala lmao