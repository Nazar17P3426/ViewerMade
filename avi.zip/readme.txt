 _______  __   __  ___  
|   _   ||  | |  ||   | 
|  |_|  ||  |_|  ||   | 
|       ||       ||   | 
|       ||       ||   | 
|   _   | |     | |   | 
|__| |__|  |___|  |___| 

avi.exe is a short GDI malware by b9tinu/comium420
Warning: This malware can delete hal.dll and disable Task Manager.
I'm NOT responsible for ANY damages.
NOT for epileptic people!
Run it ONLY in a VM.
If you didn't know, .avi is a video format
YouTube: https://youtube.com/@b9tinu