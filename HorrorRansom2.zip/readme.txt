This is a ransomware, not a joke
If you infected just run the HorrorRansom2Decryptor but don't restart your pc BEFORE you run it or your pc won't boot
The MBR restore after decryption was inspired by Slam Ransomware