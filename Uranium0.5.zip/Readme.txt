Trojan name: Uranium
Works on: WinXP+
Damage rate: Destructive
Made in: C++
Version: 0.5
Do not run on real pc, use a vm