        __                         .__       .___
  _____|  | _____.__. _____   ____ |  |    __| _/
 /  ___/  |/ <   |  |/     \_/ __ \|  |   / __ | 
 \___ \|    < \___  |  Y Y  \  ___/|  |__/ /_/ | 
/____  >__|_ \/ ____|__|_|  /\___  >____/\____ | 
     \/     \/\/          \/     \/           \/ 

skymeld is a GDI malware made by fr4ctalz and N17Pro3426.
This malware includes the destructive and safety versions.
By running the variation without the ".harmless" tag in front of it is not recommended.
The creators are NOT responsible for any damages.
Do NOT under any circumstances run this in a host PC and use this maliciously.
It will damage your computer's registry.
Programming language is C++.