nougar.exe by @mrsuperbuddy8216 (last malware?)
Ultimate destruction of computer
-----------------------------------------------
Created on: c++
Is it open source???: yes
-----------------------------------------------
WARNING!!!
Running non-peaceful version, it will destroy your computer!!! 