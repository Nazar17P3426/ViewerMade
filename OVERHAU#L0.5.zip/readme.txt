OVERHAU#L.exe (Beta Version)

this malware was made by soheil and gifted to malware testers who don't have VM.
I don't have VM and can't make MBR, so I don't make destructive yet. The beta version,
yes, you know, it was shown for people who can't wait to see OVERHAU#L.exe malware.

0.2: made in 9/4/2023 3:57 PM
0.5: made in 9/9/2023 12:28 PM (changed becuase there was a update)
1.0: SOON


0.2 Feautures:
----------------------------------------------------------------------------------------------------------------------------
Has 3 warnings, 3 payloads, 1 bytebeat, harmless

the first one is elipse payload, contains moving circles, the payload lasts about 30 seconds
the second one is bitblt payload, contains blur-like screen, the payload lasts about 60 seconds
the third one is another bitblt payload, contains instant inverted screen, the payload lasts about 30 seconds
----------------------------------------------------------------------------------------------------------------------------

0.5 Features:
----------------------------------------------------------------------------------------------------------------------------
Has the same warnings as 0.2 version, 6 payloads, 3 bytebeats, still harmless

the first one is elipse payload, contains moving circles, the payload lasts about 30 seconds
the second one is elipse payload, has patblt rectangles with transperent, contains bouncing circle, lasts about 30 seconds
the third one is bitblt payload, contains blur-like screen, the payload lasts about 60 seconds
the fourth one is another bitblt payload, contains instant inverted screen, the payload lasts about 30 seconds
the fifth one is shader payload, contains shaders with a inverted black rectangles, the payload lasts about 30 seconds
the sixith one is sinewave payload, contains weird sinewaves, the payload lasts about 60 seconds (I changed my mind about this payload)
----------------------------------------------------------------------------------------------------------------------------