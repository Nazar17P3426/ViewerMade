Wigofellium by @mrsuperbuddy8216
--------------------------------
Language: C++
Thanks to: StrychnineRaccoon, GetMbr, pankoza2 and N17Pro3426 for testing :)
What's new: Cool effects, fixed MBR overwriter, Command Prompt appears and one more time... composed bytebeat (thanks to StrychnineRaccoon for the idea)
--------------------------------
Warning:
Running Wigofellium without the ".peaceful" branch, it will destroy your computer