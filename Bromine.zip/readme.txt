██████╗ ██████╗  ██████╗ ███╗   ███╗██╗███╗   ██╗███████╗
██╔══██╗██╔══██╗██╔═══██╗████╗ ████║██║████╗  ██║██╔════╝
██████╔╝██████╔╝██║   ██║██╔████╔██║██║██╔██╗ ██║█████╗  
██╔══██╗██╔══██╗██║   ██║██║╚██╔╝██║██║██║╚██╗██║██╔══╝  
██████╔╝██║  ██║╚██████╔╝██║ ╚═╝ ██║██║██║ ╚████║███████╗
╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚══════╝
                                                         
Malware name: Bromine
Malware type: Trojan
Damage rate: Destructive
Made in: C++, asm
Works best in: Windows XP, Windows 7
if it freezes or crashes on Windows XP, try it on Windows 7 and if some effects won't appear, try enabling aero
creator: pankoza
the mbr is the pillman boot sector game: https://github.com/nanochess/Pillman
you need to have the last.wav in the directory the Bromine.exe is or the final sound won't play