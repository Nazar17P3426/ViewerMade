GDI Trojan Benzene

------------------------------------------------------------------------

This malware overwrites the computer's MBR.
 Please run it at your own risk. 
The author assumes no responsibility.

WinXP, Win10 and Win11 are recommended.
Win7 is deprecated.
If you must run on win7, please enable AeroGlass.

-------------------------------------------------------------------------

Author: Mist 
I'm Japanese

Benzene x86 Clean.exe 184kb
Benzene x86.exe 198kb
Benzene x64 Clean.exe 218kb
Benzene x64.exe 234kb

Version that does not start the applications
Benzene x86 2 148kb
Benzene x64 2 184kb