       _ __  ___   ___ ______   ___  __ __ _____               
      | /_ |/ _ \ / _ \____  |_|__ \/_ /_ | ____|              
      | || | | | | | | |  / /| |_ ) || || | |__   _____  _____ 
  _   | || | | | | | | | / /_   _/ / | || |___ \ / _ \ \/ / _ \
 | |__| || | |_| | |_| |/ /  |_|/ /_ | || |___) |  __/>  <  __/
  \____/ |_|\___/ \___//_/     |____||_||_|____(_)___/_/\_\___| (aka J100758.264+211529.207 2.0.exe)
                                                               
                                                               
Malware name: J1007+2115.exe
Malware type: Trojan
Damage rate: Destructive
Made in: C++, ASM
Works on: Windows XP-11
Creator: pankoza
Creation date: November 4 2023
The MBR is a boot sector remake of Donkey.bas called Sorry Ass: https://github.com/viler-int10h/Sorry-Ass
This malware is not a joke, run it only on VM
If you run it on the x64 version of Windows XP/Server 2003, then use the x64 version or the critical process won't work
Credits to Wipet for the HSL
Credits to ArTicZera for the HSL shader system
Credits to fr4ctalz for the HSL shader itself, but I modified it