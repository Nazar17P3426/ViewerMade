%# winRainbow.exe %#
Created by: lukonix
Created in: C, C++ and Assembly

It contains flashing images!

Don't try this in your computer, this malware is not a joke and cause damages
to your PC. I'm not responsible for any damages caused to your machine.