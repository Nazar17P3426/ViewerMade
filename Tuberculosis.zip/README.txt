Hello.
I want to show something fantastic for you.
It's Tuberculosis.exe - the inspired nikitpad and JavaFox malware!
Before you running, I want to warn you:
   * Do NOT leak it, else you will get big punishment from me
   * If someone in your video about Tuberculosis.exe is begging, screenshot it and send it to me (it will be in hall of shame) and do NOT give it, who is begging
   * NO source code, because the malware will be easly compiled and leaked (it's so dumb)
Anyways, thanks to RaduMinecraft for helping me with some payloads
Have a nice test and video!