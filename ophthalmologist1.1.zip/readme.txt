ophthalmologist.exe (last malware is Hophthalmologist.exe, this is not last)

only 6 malwares left that I needed to do, my new malware, I am slowly showcasing the model of my last malware,
my last is the shortest malware (only 3 payloads that every of them has 40 seconds) don't be mad, let's ignore the last malware -_-
ophthalmologist.exe the new (shitty, but fixed in 1.0) malware made by soheil shahrab.
all GDI's was planned for my OVERHAU#L.exe well I changed it, did you know how i got the name of malware?
Mr. Super Buddy posted a community that said: "Tomorrow I won't post a video because I'm going to the ophthalmologist"
and I got a idea and said: My next malware will be ophthalmologist.exe
then he laughed then I was really serious.

Fun fact: if you run the malware with destructive brand, it just terminates your explorer, then shuts it down.

Date created:
0.7 version (shit): 9/12/2023 7:05 PM
1.0 version (shit fix): 9/14/2023 10:35 PM
2.0 (more payloads): 9/15/2023

Compataitiblity:
OS: Windows server 2008 or Above
(minimum is not XP, becuase I am using new version of Dev-C++, but somehow it's )

Can modfiy the settings of file: no

Adminstrator needed: no, because it dosen't overwrite MBR

Size: 183 KB (188,230 bytes)




if you are N17Pro3426, then you can be my friend for once? :)