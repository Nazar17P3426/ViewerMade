Hello!
It's my new malware
OS support: Windows XP-11
There is NO SFX!
Made in: C++
Damage rate: Peaceful
Goodbye!