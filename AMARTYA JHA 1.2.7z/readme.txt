AMARTYA JHA 1.2.exe

That's right, the second iteration of the AMARTYA JHA series!

Created by: Tubercomiosis (skidded)
Malware type: Trojan
It's safety?: Yes
Programming language: C++
Made on: August 27th, 2024 (Project started over a week ago.)

Do NOT run this trojan if you have epilepsy!