Clean.Win32.Trojan
^^^^^^^^^^^^^^^^^^

Clean trojan made by LAndy

About this trojan: 
==================================================================
This trojan does not overwrites or destroys the system, it only makes the
computer to be unusable for amateurs.

Payloads after authorization:
==================================================================
1. Creating random shortcuts on desktop linking to a HTML file
2. Mirroring the screen + glitches
3. Searches on Google + bigger glitches
4. HTML file pops up and says: "Your computer has been f*cked"
5. Mirror screen + more screen glitches + falling screen effect
6. Invert screen colors
7. Restarting Windows
8. Copy itself to "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
9. After reboot, the trojan runs again

and for amateurs... it's endless...

I am not responsible for any problems

Enjoy :]
-LAndy