isopropxide.exe (short malware)
----------------------------------------------------------------------------------------------------------------------------------
this malware was made by soheil shahrab, unlike pankoza's isopropoxide, it's short and has different
RGBQUADs, if you wan't to test it, go to N17Pro3426 and find the malware with this name, if you find it,
you will be surprised, try making 2.0 version (if you test it, and please you have to do it after testing)
----------------------------------------------------------------------------------------------------------------------------------
Compatibility required: Windows Server 2008 - Windows 11
Date created:
1.0 version: 11/8/2023
2.0 version: 11/10/2023 (I made it less than 12 hours)
Destructive: No
Payloads:
1.0 version: It has 4, and each one last 60 seconds
2.0 version: Long as olthaltlzpz
Warnings:
1.0 version: dosen't even have a single one
2.0 version: 2 warnings
Bugs: gmon.out pop up.

I don't know how to make the minimum compatibility reach Windows XP,
it's still Windows Server 2008, well, I can't make destructive yet, for more, read down
----------------------------------------------------------------------------------------------------------------------------------
Reason that I can't make destructive version (I can't make MBR):
All those are lies, except for the 4th reason

1. I don't have a VM on PC (my PC has only 1 drive, 4GB RAM, it will be slower if I install VM, have older .iso like Windows 7 at all)
2. Needs additional code for source (for MBR only)
3. I can't make adminstrator mode. (for MBR only)
4 (Turth). I am scared that it I will accdientally run it and then it will kill my computer.
