Malware Name: Chlorine
Malware Type: Trojan
version 2.0
Damage Rate: Destructive
Works Best in: Windows XP
Made in: C++
Created by: pankoza
Disclaimer: This trojan is not for people with epilepsy and can really damage your system. This trojan contains loud sounds, Creator not responsible for any damages to your system, always test in a Virtual Environment
changelog:
1.0
initial release
2.0
new mbr
noise now plays in a loop
IconHell starts earlier
new icon
open source