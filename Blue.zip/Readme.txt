Made on Dev-C++
Creation date is 7/8/2023
Made by Soheilshahrab
Enjoy it, but no MBR :)

2.0 Updates

Updated on 7/20/2023
Update #1: Payload duration fixed and increased
Update #2: Added many payloads
Update #3: Fixed storage (Removed iostream & ctime, because it's useless)