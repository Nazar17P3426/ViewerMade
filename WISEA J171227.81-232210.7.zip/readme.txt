my new extreme trojan (works best in WinXP)
made in: C++
creator: pankoza
damage: Destructive
