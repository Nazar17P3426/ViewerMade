▄▄▄█████▓ ██▀███   ██▓▄▄▄█████▓ ██▓ █    ██  ███▄ ▄███▓
▓  ██▒ ▓▒▓██ ▒ ██▒▓██▒▓  ██▒ ▓▒▓██▒ ██  ▓██▒▓██▒▀█▀ ██▒
▒ ▓██░ ▒░▓██ ░▄█ ▒▒██▒▒ ▓██░ ▒░▒██▒▓██  ▒██░▓██    ▓██░
░ ▓██▓ ░ ▒██▀▀█▄  ░██░░ ▓██▓ ░ ░██░▓▓█  ░██░▒██    ▒██ 
  ▒██▒ ░ ░██▓ ▒██▒░██░  ▒██▒ ░ ░██░▒▒█████▓ ▒██▒   ░██▒
  ▒ ░░   ░ ▒▓ ░▒▓░░▓    ▒ ░░   ░▓  ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░
    ░      ░▒ ░ ▒░ ▒ ░    ░     ▒ ░░░▒░ ░ ░ ░  ░      ░
  ░        ░░   ░  ▒ ░  ░       ▒ ░ ░░░ ░ ░ ░      ░   
            ░      ░            ░     ░            ░   
                                                       
Tritium.exe
Run this trojan ONLY in a virtual machine and NOT on a real hardware!

Tritium is a dangerous trojan with many destructive effects!
Tritium can overwrite the MBR, delete System32 and destroy the Registry!

Credits to JhoPro, whypet, hessfire, pankoza, Dark-Tik, ChatGPT, Copilot
and Microsoft Documentation.

https://stackoverflow.com/questions/18260508/c-how-do-i-hide-a-console-window-on-startup
https://codeconvert.ai/