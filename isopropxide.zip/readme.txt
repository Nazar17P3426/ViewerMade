isopropxide.exe (short malware)
----------------------------------------------------------------------------------------------------------------------------------
this malware was made by soheil shahrab, unlike pankoza's isopropoxide, it's short and has different
RGBQUADs, if you wan't to test it, go to N17Pro3426 and find the malware with this name, if you find it,
you will be surprised, try making 2.0 version (if you test it, and please you have to do it after testing)
----------------------------------------------------------------------------------------------------------------------------------
Compatibility required: Windows Server 2008 to Windows 11
Date created: 11/8/2023
Destructive: No
Payloads: It has 4, and each one last 60 seconds
Warnings: I dosen't even have a single one
Bugs: gmon.out pop up.

I don't know how to make the minimum compatibility reach Windows XP,
it's still Windows Server 2008, well, I can't make destructive yet, for more, read down
----------------------------------------------------------------------------------------------------------------------------------
Reason that I can't make destructive version (I can't make MBR):

1. I don't have a VM on PC (my PC has only 1 drive, 4GB RAM, it will be slower if I install VM, have older .iso like Windows 7 at all)
2. It needs additional code for source (for MBR only)
3. I can't make adminstrator mode. (for MBR only)
4 (Turth). I am scared that it I will accdientally run it and kill my computer.