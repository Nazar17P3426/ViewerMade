KOSIBA YO 2.0.exe

fun fact: try putting it in Google Translate, then at the up of KOSIBA YO, select Detect Language,
and then for the second one, select the English, so, you can see a word hehehehe... >:)

Date created:

0.9 version: 11/23/2023
1.0 version: skipped to 2.0 lol
2.0 version: 11/29/2023 (the update is big)
2.1 version: 11/30/2023 (short update that adds 2 payloads)

It doesn't have a warning, also it's barely long as pankoza's last malware (in future)
I think this looks like a leak of pankoza's malware for some payloads and now
it's long as my Blue.exe (it has 2 times mores payloads than blue)