Symbolism.exe

a joke program made by me