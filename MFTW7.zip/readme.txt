Extract MFTW7 in your PC!
Start the program called MFTW7 as administrator!
Enjoy! :D




Angry Cow