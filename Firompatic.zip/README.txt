 ╔═══╗                       ╔╗                     
 ║╔══╝                      ╔╝╚╗                    
 ║╚══╗╔╗╔═╗╔══╗╔╗╔╗╔══╗╔══╗ ╚╗╔╝╔╗╔══╗  ╔══╗╔╗╔╗╔══╗
 ║╔══╝╠╣║╔╝║╔╗║║╚╝║║╔╗║╚ ╗║  ║║ ╠╣║╔═╝  ║╔╗║╚╬╬╝║╔╗║
╔╝╚╗  ║║║║ ║╚╝║║║║║║╚╝║║╚╝╚╗ ║╚╗║║║╚═╗╔╗║║═╣╔╬╬╗║║═╣
╚══╝  ╚╝╚╝ ╚══╝╚╩╩╝║╔═╝╚═══╝ ╚═╝╚╝╚══╝╚╝╚══╝╚╝╚╝╚══╝
                   ║║                               
                   ╚╝                               

Info:
{
	Made in: 3 days
	Made by: WARLOKK28, ShadowHyper4925 (Helper)
}

Note from WARLOKK28
{
	Hi, uhh this malware is safe to run on main PC, because I don't want to make MBR overwrite or
	something like this, thanks for downloading this cool project made by me, have fun testing it :)
	also no source code, because of skidders can steal my code >:(
}