████████╗██████╗ ██╗██████╗ ██╗  ██╗███████╗███╗   ██╗██╗   ██╗██╗      █████╗ ██████╗ ███████╗██╗███╗   ██╗███████╗
╚══██╔══╝██╔══██╗██║██╔══██╗██║  ██║██╔════╝████╗  ██║╚██╗ ██╔╝██║     ██╔══██╗██╔══██╗██╔════╝██║████╗  ██║██╔════╝
   ██║   ██████╔╝██║██████╔╝███████║█████╗  ██╔██╗ ██║ ╚████╔╝ ██║     ███████║██████╔╝███████╗██║██╔██╗ ██║█████╗  
   ██║   ██╔══██╗██║██╔═══╝ ██╔══██║██╔══╝  ██║╚██╗██║  ╚██╔╝  ██║     ██╔══██║██╔══██╗╚════██║██║██║╚██╗██║██╔══╝  
   ██║   ██║  ██║██║██║     ██║  ██║███████╗██║ ╚████║   ██║   ███████╗██║  ██║██║  ██║███████║██║██║ ╚████║███████╗
   ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝╚═╝  ╚═══╝╚══════╝
                                                                                                                   
Malware name: Triphenylarsine
Type: Trojan
Damage rate: Destructive
Made in: C++
Made by: pankoza
Works best in: Windows XP, Windows Vista, Windows 7
Creation date: 23.08.2022

This is very dangerous for the non-safety version, the non safety version will damage your MBR and disable your task manager, but the Safety version is safe to run on real PC
The MBR is the same image as in Heptoxide.exe's MBR, but in bit different colors
The creator is not responsible for any damages made using this malware