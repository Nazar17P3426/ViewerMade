Ethylenediaminetetraacetate.exe by pankoza
I know I said APM 08279+5255.exe would be my last GDI Malware, but I made another one just to Celebrate new year 2024 (Man I can't believe 2014 was 10 years ago!, which means Windows 8.1 will be 11 years old this year!)
Works on Windows XP-11 (but XP is recommended)
The non-safety version will destroy your PC when you run it, I'm not responsible for any damages, because this malware was created for educational purposes only!
Credits to EthernalVortex for the PRGBQUAD system
Credits to ArTicZera and Wipet for the HSL
Credits to GetMBR for the Hue function
Credits to N17Pro3426 for some bytebeat
Creation time December 31 2023 - January 1 2024
As always this malware contains flashing lights and earrape, not for epilepsy
If you want to run it on Windows XP/Server 2003 x64 Edition, then use the x64 version or it won't set itself as critical process
This is probably my last malware for real this time























































































Hi fr4ctalz, N17Pro3426, Crypto NWO and RainflowBoi, if you are reading this, hi, and I can't believe it's already 2024