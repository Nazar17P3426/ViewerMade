'##::::'##:'########:'##::::'##::::'###:::::'######::'##::::'##:'##::::::::'#######::'########:::'#######:::'######::'##:::'##::'######::'##::::::::'#######::'##::::'##:'########:'##::::'##::::'###::::'##::: ##:'########:
 ##:::: ##: ##.....::. ##::'##::::'## ##:::'##... ##: ##:::: ##: ##:::::::'##.... ##: ##.... ##:'##.... ##:'##... ##:. ##:'##::'##... ##: ##:::::::'##.... ##: ##:::: ##: ##.....::. ##::'##::::'## ##::: ###:: ##: ##.....::
 ##:::: ##: ##::::::::. ##'##::::'##:. ##:: ##:::..:: ##:::: ##: ##::::::: ##:::: ##: ##:::: ##: ##:::: ##: ##:::..:::. ####::: ##:::..:: ##::::::: ##:::: ##: ##:::: ##: ##::::::::. ##'##::::'##:. ##:: ####: ##: ##:::::::
 #########: ######:::::. ###::::'##:::. ##: ##::::::: #########: ##::::::: ##:::: ##: ########:: ##:::: ##: ##:::::::::. ##:::: ##::::::: ##::::::: ##:::: ##: #########: ######:::::. ###::::'##:::. ##: ## ## ##: ######:::
 ##.... ##: ##...:::::: ## ##::: #########: ##::::::: ##.... ##: ##::::::: ##:::: ##: ##.. ##::: ##:::: ##: ##:::::::::: ##:::: ##::::::: ##::::::: ##:::: ##: ##.... ##: ##...:::::: ## ##::: #########: ##. ####: ##...::::
 ##:::: ##: ##:::::::: ##:. ##:: ##.... ##: ##::: ##: ##:::: ##: ##::::::: ##:::: ##: ##::. ##:: ##:::: ##: ##::: ##:::: ##:::: ##::: ##: ##::::::: ##:::: ##: ##:::: ##: ##:::::::: ##:. ##:: ##.... ##: ##:. ###: ##:::::::
 ##:::: ##: ########: ##:::. ##: ##:::: ##:. ######:: ##:::: ##: ########:. #######:: ##:::. ##:. #######::. ######::::: ##::::. ######:: ########:. #######:: ##:::: ##: ########: ##:::. ##: ##:::: ##: ##::. ##: ########:
..:::::..::........::..:::::..::..:::::..:::......:::..:::::..::........:::.......:::..:::::..:::.......::::......::::::..::::::......:::........:::.......:::..:::::..::........::..:::::..::..:::::..::..::::..::........::

Hexachlorocyclohexane.exe by pankoza

A medium-long C++ GDI Malware (has 15 payloads, lasts 7 minutes and 30 seconds, betweeen olthaltlzpz and btfoiuthns)
This is very dangerous for the non-safety version, the non-safety version will damage the MBR, and make the PC unusable
on Windows Vista and newer it will also corrupt Boot\BCD
Works on Windows XP-11, but especially well on XP, Vista and 7
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy, that's why even the safety version has execution warnings!
As always this was created for educational purposes only. I'm not responsible for any damages and misuse of this malicious software for evil purposes by others, this malware displays 2 warning message boxes to prevent many accidents from happening!
Credits to ArTicZera and Wipet for the HSL RGBQUAD
Credits to ArTicZera and Rekto for the blur effect
Credits to GetMBR for the Hue function
Creation time: from September 27 to September 29 2023 (I've been making many malwares this month lmao)

Thanks to fr4ctalz for the base for some HSL shaders
Huge thanks to N17Pro3426 for some payloads, without him this malware wouldn't be possivle (shader2, radial, ColorREF RndRGB etc.)
I recommend you to use a wallpaper that doesn't consist mostly of white and/or black color, because otherwise you won't see the HSL shaders well














































Hi fr4ctalz, N17Pro3426, RainflowBoi and Crypto NWO, if you are reading this, hi

also Scam Sandwich, if you are reading this, huge thanks for using my Phallolysin and my very old PankozaDestructive 2.0 to ruin Tech Support Scammers