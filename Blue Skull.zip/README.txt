-------------------------------------------------------------------------------------------------------------
Creator: ClutterTech
Please support me by subscribing: https://www.youtube.com/channel/UC9keh4wDjXFyiRhHDE_h90Q?view_as=subscriber
Version: 1.0.0
Virus type: Locker
You can find the correct code on my video: D
-------------------------------------------------------------------------------------------------------------