Abrakadabrium
--------------------------
My new malware on C++

Credits to TruLone for the 2 final payloads (14 and 15 payload)