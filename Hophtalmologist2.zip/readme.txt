Questions:
you can ask me a question about this malware by commenting on https://www.youtube.com/watch?v=EUwWDzGezoA
you don't need to ask me about the date created or the destruction.

Information:

Destructive: False
Duration:

0.7 version: 3 minutes
0.8 version: 6 minutes
1.0 version: 10 minutes

Testable: True

Date created:
0.7 version: 10/4/2023
0.8 version: 10:15/2023
1.0 version: I don't know

Similar malwares: Krypton.exe, Getaparane.exe (viewer made malware / for the fifth payload of my malware)

Warning:
The sounds are loud and there's too much shader,
so, if you have weak PC or eplipsy, please don't run it
otherwise, your computer (if it's weak) or you will be in danger

Note:
this malware is in beta version, you can only ask soheil shahrab, this is not destructive and
it's safe, but also legendary as Blue.exe and Conductive.exe. so do you know


