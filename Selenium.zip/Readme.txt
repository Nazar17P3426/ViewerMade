Selenium.exe
My new malware with 4 payloads!
Seizure & earrape warning!
This malware is safe to run on a real PC, but it can cause seizures, earrape and screen burns, so be careful!
Thanks to ChatGPT for helping me to fix the errors in the codes.