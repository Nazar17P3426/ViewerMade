Selenium.exe

My new GDI malware!
Seizure warning!

This GDI malware is safe to run on a real computer, but it can cause seizures, earrape and
screen burns, so, be careful!

Also, thanks to ChatGPT for fixing errors in the codes.