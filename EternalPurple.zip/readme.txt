EternalPurple.exe
~~~~~~~~~~~~~~~

Created by: EmmyMalware
Better version by: N17Pro3426

My first GDI malware in C++.
It has destructive and safety versions.