Cansy.exe
Mr. Super Buddy's LAST malware forever
------------------------------------
Language: C++
Yes, it works without vc_redist!
Similar to detamiretniw, Getaparane (first effect), HSLPHONE (future 2.0 version), NocturV2
------------------------------------
If soheil shahrab, N17Pro3426, pankoza, fr4ctalz or Crypto NWO reading this now, please, rate my last forever work :(
bye (:()/