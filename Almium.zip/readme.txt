AAAAAAAAAA |        MMM    MMM _______ ___    ___ MMM    MMM
AAA    AAA |        MMM    MMM   | |   | |    | | MMM    MMM
AAA    AAA |        MMMM  MMMM   | |   | |    | | MMMM  MMMM
AAAAAAAAAA |        MMM MM MMM   | |   | |    | | MMM MM MMM
AAA    AAA |        MMM    MMM   | |   | |    | | MMM    MMM
AAA    AAA -------- MMM    MMM _______ |_|____|_| MMM    MMM

Dimently good!
----------------------------------------------------------------------------------------------------------------
Creator: Mr. Super Buddy (YouTube: https://youtube.com/@mrsuperbuddy8216)
Language: C++
Thanks to pankoza for some bytebeats and shutdown code
----------------------------------------------------------------------------------------------------------------
WARNING!
This is a considered malware, so, if you running Almium with the peaceful branch, you'll be safe
----------------------------------------------------------------------------------------------------------------
News!
I learned, how to BSOD, so, in next malware, I add this:
#pragma <"ntdll.lib">
----------------------------------------------------------------------------------------------------------------
That's all :)