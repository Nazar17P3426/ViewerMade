EN: Don't Run this on your real PC!!!

PL: Nie Uruchamiaj Tego na prawdziwym Komputerze!!!