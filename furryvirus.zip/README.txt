This .zip was created, so, that you can run my malware called furryvirus.exe on an operating
system as old as Windows Vista, it will not work on Windows XP as .NET Framework 4.5.1
does not support that operating system.
=====================================================================================
Compatiable versions:
Windows Vista, 7, 8, 8.1, 10 (framework installer not needed as this framework version is built
into Windows 10) and 11
=====================================================================================
Made by: Sky The Foxx