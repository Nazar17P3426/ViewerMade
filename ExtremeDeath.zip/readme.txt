ExtremeDeath.exe Win32 Trojan
This trojan is no joke! Run it only on vm!
This trojan erases MBR, BCD, LogonUi and Taskmgr