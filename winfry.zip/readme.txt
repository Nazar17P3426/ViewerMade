www  www  www _______ nnnn   nnn _________ ________  yyy  yyy
www  www  www   | |   nnn n  nnn |         |      |  yyy  yyy
www  www  www   | |   nnn  n nnn -------   |      |   yyyyyyy
www  www  www   | |   nnn   nnnn |         --------       yyy
 wwwwwwwwwww  _______ nnn    nnn |         | |    \\ yyyyyyy

I hate swimming pools!
----------------------------------------------------------------------------------------------------------------
Creator: Mr. Super Buddy (YouTube: https://youtube.com/@mrsuperbuddy8216)
Language: c++
What's new: finally, I made the malware with icon!
----------------------------------------------------------------------------------------------------------------
WARNING!
This is a considered malware, so if you running winfry with the peaceful branch, you'll be safe.