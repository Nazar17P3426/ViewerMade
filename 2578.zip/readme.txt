 _____  _____  ___________ 
/ __  \|  ___||___  /  _  |
`' / /'|___ \    / / \ V / 
  / /      \ \  / /  / _ \ 
./ /___/\__/ /./ /  | |_| |
\_____/\____/ \_/   \_____/
                           
Collab with N17Pro3426.
Creation Date: 2/7/2024

WARNING: This malware can damage your MBR and make your PC unusable. I'm not responsible for any damage!