Hello guys, Conductive.exe is here, this is a malware made by soheil shahrab
I want to make TestHydrolomatic.exe (after Conductive.exe), well the source is soon :)
Unlike my previous malwares, Conductive.exe has HSL payloads without crash
(dark shader might result in fast crash because of a bug, but it works for me)

well, this took long becuase of school and other things.

Date requested to make: 9/23/2023
Date created and finished: 9/29/2023

Took 6 days :( let's forget about the Conductive.exe, as you can see, Hophthalmologist.exe (my last malware)
I have 5 malwares left remaining to make, (some can be randomized)

Do you want to Hophthalmologist.exe be long or short

1) Short
2) Long

Enter your answer here: