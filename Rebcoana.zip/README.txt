This malware was made only for educationnal purposes.

You are responsible if you execute it on a real computer.

Credits for this malware go to:

Sclerosis#8349 (youtube channel link: https://www.youtube.com/channel/UCHGF3pq0RqcBQ8Mgd5WHq8w/videos)

Deep Freeze#3847 (youtube channel link: https://www.youtube.com/channel/UCmkpwHgs7Fexre_s0UICwSw)

btw the user password on the renamed account GET is rekt. If this password doesn't work, try to type your old passowrd.

if you see anything like "the user or password is incorrect" after it rebooted, just press ok and type the good password and it will log you in.