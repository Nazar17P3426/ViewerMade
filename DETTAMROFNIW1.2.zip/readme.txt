DETTAMROFNIW.exe by pankoza
C++ GDI Malware
Made for Educational purposes only
I'm not responsible for any damages!
Works in Windows XP-11
Creation date: 12 March 2023
This is very dangerous for the non-safety version
The non-safety version will overwrite the MBR and make the PC unbootable and unusable
Run it only on VM
Epilepsy Warning: If you are sensitive to flashing lights or loud sounds, then don't even watch this malwares

Fun Fact:
DETTAMROFNIW is WINFORMATTED in reverse

Credits:
EthernalVortex - PRGBQUAD
Void_/GetMBR - Hue Function
Mist0090 - random .exe opening (from FakeHolzer.exe) - removed in 1.2

updated version (13.03.2023):
Fixed the last payload on Windows 7 without Aero/DWM
no longer requires Visual C++ redistributable 2015 (x86) to run, as i changed the "Multi-Threaded DLL" option to "Multi-Threaded"

1.2 version (May 6 2024)
new MBR and removed the program spamming function, because it lagged the GDI too much