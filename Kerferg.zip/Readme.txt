Kerferg.exe
My first ever C# malware!
This is also my first malware that has LayeredWindows, although it doesn't works.
Credits to ChatGPT for teaching me the basics of C#!
N17Pro3426, Vexify, Marlon2210, ComiDaIcon (Comium92), Tubercomiosis (Sensist2011Cringe), cesiumxx (Mr. Super Buddy), ExpertWorks4417, Aung208, A Russian Guy, RaduMinecraft, Jern216, pankoza, fr4ctalz, PankozaTrojans, pankoza3, kapi2.0peys, Minhgotuknight19 (Tromiute), kapi2.5peys archive, Vistamations, the_xj (Abyss Guardian), yedb0y33k, WinMalware and everyone else
If you're reading this, then hi! :)
Enjoy!