
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█▄─▄▄─█─▄▄▄▄█▄─▄▄─█▄─██─▄█▄─▄▄▀█─▄▄─█─█─█▄─▄▄─█▄─▄▄▀█▄─▀█▀─▄██▀▄─██▄─▄▄─█─█─█▄─▄▄▀█─▄▄─█▄─▄▄▀█▄─▄█─▄─▄─█▄─▄█─▄▄▄▄█▄─▀█▀─▄█
██─▄▄▄█▄▄▄▄─██─▄█▀██─██─███─██─█─██─█─▄─██─▄█▀██─▄─▄██─█▄█─███─▀─███─▄▄▄█─▄─██─▄─▄█─██─██─██─██─████─████─██▄▄▄▄─██─█▄█─██
▀▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▀▄▄▄▄▀▀▄▄▄▄▀▀▄▄▄▄▀▄▀▄▀▄▄▄▄▄▀▄▄▀▄▄▀▄▄▄▀▄▄▄▀▄▄▀▄▄▀▄▄▄▀▀▀▄▀▄▀▄▄▀▄▄▀▄▄▄▄▀▄▄▄▄▀▀▄▄▄▀▀▄▄▄▀▀▄▄▄▀▄▄▄▄▄▀▄▄▄▀▄▄▄▀

Malware name: pseudohermaphroditism.exe
Creation date: 6/2/2024
Done date: 7:07 PM 6/8/2024
Creator: WinMalware
Type: C++
Damage rate: Very destructive (for non-safety version), very low (ONLY for safety version)

This is very dangerous for the non-safety version! 
It will destroy this computer by overwriting MBR and completely corrupt the registry, also it can corrupt your hard drive and completely deletes from your computer!

Btw, this is a skidded malware!