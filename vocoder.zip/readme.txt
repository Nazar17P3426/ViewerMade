vocoder by @mrsuperbuddy8216
----------------------------
Created on: C++
Thanks to: sohiel shahrab and others...
----------------------------
WARNING!!!
Running non-peaceful version will destroy your computer!
The creator is not responsible for any damages!