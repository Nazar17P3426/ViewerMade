This is a malware not a joke do not run on real pc
created by pankoza