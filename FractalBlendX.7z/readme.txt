FractalBlendX.exe
Creator: Comium92
Made in: Dev-C++
Credits to nikitpad for the MBR
Credits to The Mayn Mike for some payloads
Credits to pankoza for some shaders
Credits to dollchan.net for the bytebeats