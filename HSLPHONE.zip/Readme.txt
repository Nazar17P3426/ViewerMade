Made on Dev-C++
Safety version: 7/11/2023
Destructive version: NEVER (until I will find a VM)

Made by Soheilshahrab, there are no damages.
Enjoy it, but you can run (unless if you have epliepsy or don't want your screen to be messed up)
No MBR, of course if you restart your PC, you still boot into Windows :)

WARNING:
If you have epliepsy, please don't run it!
This can mess up your screen, if you don't want your screen messed up, please don't run it.