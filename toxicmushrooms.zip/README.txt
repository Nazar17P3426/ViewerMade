this version of Monoxide was created by General Techy Boi (that's me :D)
credits to whypet for the source code

toxicmushrooms.exe does not contain any of the harmful code from the
original version, all of that was removed.