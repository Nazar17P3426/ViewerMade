Francium by @mrsuperbuddy8216
-----------------------------
Language: C++
Thanks: pankoza, wipet
(I don't have a time for a full readme)
-----------------------------
WARNING!
Running Francium without the ".peaceful" branch, it will destroy your computer