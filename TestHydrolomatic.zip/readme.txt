Questions
~~~~~~~~~~
You can ask me a question about this malware by commenting
on https://www.youtube.com/watch?v=EUwWDzGezoA

Don't ask me about download until pankoza comments on my second
video, but unlike my future and old malwares, it's private.

You don't need to ask me about the date created or the destruction.

Information
~~~~~~~~~~
Destructive: False
Duration: 4 minutes
Testable: False (unless, if it's public)
Date created: 10/4/2023
Similar malwares: Blue

Warning!
~~~~~~~~~~
The sounds are loud and there's too much shader.
So, if you have weak PC or eplipsy, please don't run it.
Otherwise, your computer (if it's weak) or you will be in danger.

Note
~~~~~~~~~~
RandomRR was unsendable becuase it was against google guidelines,
but this malware is sendable but its private so, if you sad then I have a
similar malware for you. This malware is private, you can only ask soheil
shahrab, this is not destructive and it's safe, but also legendary as Blue
and Conductive, the malware is called TestHydrolomatic, what? the name
seems boring -_-