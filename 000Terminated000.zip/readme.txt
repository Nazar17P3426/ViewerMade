000Terminated000.exe (very long trojan)

This malware was made by soheil shahrab, why I didn't know all of my malwares were able to run on
Windows XP, now I know it, unlike Kapi2.0Peys.exe, it dosen't contain quizes until I add a C# to C++ code.
Also, here is the source code for you :), I forgot for the previous malware. Also there is some HSL RGBQUAD
that I made using VortexGTX's RGBQUAD, and some 3D graphics like effects with RGBQUADs.

1.0 version is the EvilMsgBox, but 2.0 version is the 000Terminated000
---------------------------------------------------------------------------------------------------------------------------------
Compatibility required: Windows XP or above

Creation dates:
1.0 version: 3/19/2024
2.0 version: 3/21/2024

Destructive: No

Payloads:
1.0 version: Long as Blue.exe, but only the 2 last payloads have 60 seconds.
2.0 version: Almost long as (or longer than) Blue2.0.exe

Message boxes:
Warnings: 1
Ask: 1
Annoying or cursed: 5 (for 2.0 version is only 1)
---------------------------------------------------------------------------------------------------------------------------------
Reason that I can't make destructive version:

1. I am scared that it i will accdientally run it and then it will kill my computer.
2. I don't want to damage anyone's computer.
---------------------------------------------------------------------------------------------------------------------------------
Credits to pankoza for the GDI effects
Credits to PortablePoreclain for the final payload bytebeat of 1.0 version
Credits to Chasyxx for the second final payload bytebeat of 1.0 version