Bonzify.exe

A trojan created for Vinesauce Joel's Windows Vista Destruction.
This is destructive malware, don't compile and run it if you don't know the risks!

I'm NOT responsible for ANY damage caused by my malware!

100% real allowed by Leurak and Joel