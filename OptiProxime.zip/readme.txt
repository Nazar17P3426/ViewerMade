Hello guys, this is my first malware on GitHub, OptiProxime.exe is here
Another randomized malware (Previous randomized one was RandomRR.exe)

This one also needs SOHEIL1.wav in the same location as "OptiProxime.exe"
So, if you are a skidder, get out here stalker (or skidder)

2.0 (and above): Credits to ArTicZera for the bouncing icon and RGBQUAD models (I modified it)
1.0 (and above): Credits to ArTicZera for the HSL system (I modified it's color, so, it can work on my coder)
1.0 (and above): Credits to GetMbr for Hue function
1.0 (and above): Credits to VortexGTX for PRGBQUAD
1.0 (and above): Credits to pankoza for GradientFill (I used HdcMem for combination with BitBlt)

Important note: there's also a non-random version for 2.0 if you want to see
the payloads that hasn't shown in the randomized one, then try non-randomized