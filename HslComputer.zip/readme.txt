HslComputer.exe (HslPhone Remade)

This malware was made by soheil shahrab, unlike hslphone, there wasn't a non-colorful payload,
all payloads were colorful, if you wan't to test it, go to N17Pro3426 and find the malware with this
name, if you find it, you will be surprised.

Compatibility required: Windows Server 2008 - Windows 11
Date created: 9/9/2023 10:20 PM
Destructive: No
Payloads: It has 5, and each one last 30 seconds
Warnings: 3 (it's safe malware, so ignore it)

I don't know how to make the Minimum Compatibility reach Windows XP, it's still Windows Server 2008
well, I can't make destructive, if you wan't reasons that I can't make destructive:

--------------------------------------------------------------------------------------------------------------------------------------

Reason that I can't make destructive version (I can't make MBR):

1. I don't have a VM on PC (my PC has only 1 drive, 4GB ram, it will be slower if I install VM, I have older ISO like Windows 7 at all)
2. Needs additional code for source (for MBR only)
3. I can't make adminstrator mode.
