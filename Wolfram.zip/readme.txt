
 __      __       __   _____                                                
/  \    /  \____ |  |_/ ____\___________    _____       ____ ___  ___ ____  
\   \/\/   /  _ \|  |\   __\\_  __ \__  \  /     \    _/ __ \\  \/  // __ \ 
 \        (  <_> )  |_|  |   |  | \// __ \|  Y Y  \   \  ___/ >    <\  ___/ 
  \__/\  / \____/|____/__|   |__|  (____  /__|_|  / /\ \___  >__/\_ \\___  >
       \/                               \/      \/  \/     \/      \/    \/ 


___  ___  ___ ______ _____  ________   __  ___________ _   _ _     _____ _   _  _____ 
|  \/  | / _ \|  _  \  ___| | ___ \ \ / / |_   _| ___ \ | | | |   |  _  | \ | ||  ___|
| .  . |/ /_\ \ | | | |__   | |_/ /\ V /    | | | |_/ / | | | |   | | | |  \| || |__  
| |\/| ||  _  | | | |  __|  | ___ \ \ /     | | |    /| | | | |   | | | | . ` ||  __| 
| |  | || | | | |/ /| |___  | |_/ / | |     | | | |\ \| |_| | |___\ \_/ / |\  || |___ 
\_|  |_/\_| |_/___/ \____/  \____/  \_/     \_/ \_| \_|\___/\_____/\___/\_| \_/\____/ 
                                                                                      
                                                                                      
========================================================================================================================================

Wolfram.exe is a GDI malware written in C created only for educational purposes and should NEVER be ran on a real machine as it is really destructive.

One of the few things it do is overwrite the disk, delete system files, force restart the PC, and set itself as critical.
Do not ever run this on a real machine! This is really destructive and if you do, i am not responsible for any damages made using this trojan.

also run this only on dwm or else i will kill you

