Iconizer by @mrsuperbuddy8216
-----------------------------
Maded in: C++
Thanks to: pankoza, EternalVortex (for rgbquad)
I'm thinking, this is my last malware ever, but not
After this trojan, I'm going to school
And I don't have more time to do malwares :(
-----------------------------
WARNING!!!
Running Iconizer without .peaceful branch, it will corrupt mbr (master boot record)
I'm not responsible for any damages
-----------------------------
bye August :(