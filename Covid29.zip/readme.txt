Malware Name: Covid-29
Type: Ransomware, Wiper
Damage Rate: Destructive+
Made In: Chaos Builder, C++, Visual Basic 6.0

This ransomware is made for educational purposes only, don't use it for cybercrime or cyberweapon
This ransomware is a Wiper, it can't be Decrypted and Removed