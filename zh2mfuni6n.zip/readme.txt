  ______     ____             __       _   _ ___ __         
 |__  / |__ |___ \ _ __ ___  / _|_   _| \ | |_ _/ /_  _ __  
   / /| '_ \  __) | '_ ` _ \| |_| | | |  \| || | '_ \| '_ \ 
  / /_| | | |/ __/| | | | | |  _| |_| | |\  || | (_) | | | |
 /____|_| |_|_____|_| |_| |_|_|  \__,_|_| \_|___\___/|_| |_|
                                                            
created by pankoza
This is a simple trojan made in c++ and AutoHotkey that will overwrite mbr, spam programs and do a crazy window effect
this will overwrite mbr so run only on vm i'm not responsible for any damages