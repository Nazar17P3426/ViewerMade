Chromoxide by @mr.superbuddy8126
--------------------------------
Language: C++
It is skid?: the effects are skidded, but sounds no *one effect the text "FEEL THIS CHAOS" is not skidded*
Thanks: GetMbr, pankoza (he can't do malwares now :( ) and all my subscribers
Bugs: yeah, it appears, because, it's my first malware! Command Prompt appears, some effects or sounds are not played, if you running on windows 10, the text "FEEL THIS CHAOS" will not property work
OS recommended: Windows XP, Vista, 7 (on Windows 8/8.1, 10 and 11 the textout "FEEL THIS CHAOS" will not property work)
---------------------------------
Warning:
Running Chromoxide without the ".peaceful" branch, it will crash your computer.
I am not responsible for any damages!