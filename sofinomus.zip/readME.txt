﻿             __ _                                 
  ___  ___  / _(_)_ __   ___  _ __ ___  _   _ ___ 
 / __|/ _ \| |_| | '_ \ / _ \| '_ ` _ \| | | / __|
 \__ \ (_) |  _| | | | | (_) | | | | | | |_| \__ \
 |___/\___/|_| |_|_| |_|\___/|_| |_| |_|\__,_|___/
                                                  
----------------------------------------------------------------------------------
This is a destructive virus that overwrite MBR and do some graphical payload!
Use in a sandboxie or a VM at your own risk! I'm NOT responsible for ANY damage
made using this virus!

Who can test: MalwareTester, HackerMotherFucker, Clutter Tech, Joshua, N1CK_GAME,
viruscheck, NoFileFound.
----------------------------------------------------------------------------------
Have fun.

Special thanks for N1CK_GAME (nywal) and Joshua for making this with me!
----------------------------------------------------------------------------------
My discord: abcd19#5958
Nywal's discord: ɴʏᴡᴀʟ.#3359
Joshua's discord: Zer0exc3ption#6127