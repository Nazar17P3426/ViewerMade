NOTE: this malware is made by soheil shahrab, another HSL short malware, if you suggest to test this malware, please credit me
So, this malware has only HSL RGBQUAD and it has 4 payloads, the RGBQUAD is not offical or not completely same as the JhoPro (it was, but I removed Min and Max)
if you can see, my last malware called Krypton.exe, oh wow, this is same as Krypton and it's colorful of course

Creation date: 10/9/2023
Malwares left to make: 2 malwares (next one is long, but last is longer)
Warnings: only 1