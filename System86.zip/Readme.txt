System86.exe
Beta creepy project

Any damage to your computer caused by this software is at your own risk and the author will not be held responsible.
I also recommend that you run this software on a virtual machine.
OS support: Windows 8, 8.1, 10 and 11

このソフトによるコンピューターへのダメージは全て自己責任となり、作者は責任を取りません。
また、バーチャルマシン上での実行を推奨します
OS対応: Windows 8, 8.1, 10 そして 11

Date / 日にち:
12/13 (GDI payload - GDIペイロード)
4/20 (sound payload - サウンドペイロード)
6/7 (2nd GDI payload - 二個目のGDIペイロード)
9/11 (overwrite all .exe files payload - .exeファイル無効ペイロード)
11/1 (overwrite MBR - MBRの上書き)

Coded by NEKOTONKATU