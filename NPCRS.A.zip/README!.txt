##     #  #####   ######  #####   #####       ##
# #    #  #    # #      # #    # #           #  #
#  #   #  #    # #        #    # #          #    #
#   #  #  #####  #        #####   #####     ######
#    # #  #      #      # #    #       #    #    #
#     ##  #       ######  #    #  #####  #  #    # 

______________________________________________________
                      [By GetMbr]
------------------------------------------------------

Password: getmbr

This malware can delete hal.dll, ci.dll and even disk.sys
also it can overwrite your computer as a result of a un-
usable machine!

This malware is made of course of 3 days. Isnt pretty though?

Anyways this malware is for educational purposes only! The cr-
eator is not any responsible for any damages!

Discord: GetMbr#2137
Reddit: https://reddit.com/u/GetMbr