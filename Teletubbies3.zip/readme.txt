Teletubbies3.exe by pankoza
Short C++ GDI Malware.
I'm not responsible for any damages
Credits to EthernalVortex for PRGBQUAD