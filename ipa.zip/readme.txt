ipa
--------------------------
My new short malware.

Wikipedia about it: https://appmaster.io/blog/what-is-an-ipa-file-how-to-open