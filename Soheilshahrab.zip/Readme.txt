Made on Dev-C++
1.0 version: 7/8/2023
1.5 version: 6/24/2023
2.0 version: 6/27/2023
Made by Soheilshahrab
Enjoy it, but no MBR :)