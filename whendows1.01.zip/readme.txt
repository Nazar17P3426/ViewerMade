░██╗░░░░░░░██╗██╗░░██╗███████╗███╗░░██╗██████╗░░█████╗░░██╗░░░░░░░██╗░██████╗
░██║░░██╗░░██║██║░░██║██╔════╝████╗░██║██╔══██╗██╔══██╗░██║░░██╗░░██║██╔════╝
░╚██╗████╗██╔╝███████║█████╗░░██╔██╗██║██║░░██║██║░░██║░╚██╗████╗██╔╝╚█████╗░
░░████╔═████║░██╔══██║██╔══╝░░██║╚████║██║░░██║██║░░██║░░████╔═████║░░╚═══██╗
░░╚██╔╝░╚██╔╝░██║░░██║███████╗██║░╚███║██████╔╝╚█████╔╝░░╚██╔╝░╚██╔╝░██████╔╝
░░░╚═╝░░░╚═╝░░╚═╝░░╚═╝╚══════╝╚═╝░░╚══╝╚═════╝░░╚════╝░░░░╚═╝░░░╚═╝░░╚═════╝░

I remade cat's scratch malware.
This C++ safety GDI recreated malware was made by Tubercomiosis99 on August 3rd, 2024.
It's skidded.

If you want the last sound to play, make sure you have sfx6.wav in the same directory as the .exe!
Release 1.01 - Fixed the bytebeat that NOT working on Windows XP, and made it sync with the payloads.