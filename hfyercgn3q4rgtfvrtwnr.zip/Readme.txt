hfyercgn3q4rgtfvrtwnr.exe
My new malware!

Note: this malware is the recreation of hfyercgn3q4rgtfvrtwnr.exe that is made in Scratch.mit.edu by leotcs39.
Here is the link to the Scratch project: https://scratch.mit.edu/projects/1017258661/