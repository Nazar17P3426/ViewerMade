█████ █████ █    █     ███   ███   ███  █████ █   █  ███   ███ █████  ███  █   █ █   █ █████ ████   ███  ████  ████   ███  █  █ █   █ █   █ █   █ ████  █████  ███  █   █  ███    █████ █   █ █████ █
█     █     █    █    █   █ █   █ █   █ █     █   █ █     █      █   █   █ █   █ █   █   █   █   █ █   █ █   █ █   █ █   █ █ █  █   █ ██  █ █   █ █   █   █   █   █ █   █ █       █      █ █  █     █
█████ █████ █    █    █   █ █     █   █ ███   █   █  ███  █      █   █   █ █   █ █████   █   ████  █   █ ████  ████  █   █ ██   █   █ █ █ █ █   █ ████    █   █   █ █   █  ███    █████   █   █████ █
█     █     █    █    █   █ █  ██ █   █ █     █   █     █ █      █   █   █ █   █ █   █   █   █     █   █ █     █     █   █ ██   █   █ █  ██ █   █ █ █     █   █   █ █   █     █   █      █ █  █     █
█████ █████ ████ ████  ███   ████  ███  █      ███   ███   ███ █████  ███   ███  █   █ █████ █      ███  █     █      ███  █ █   ███  █   █  ███  █  █  █████  ███   ███   ███  █ █████ █   █ █████ █
                                                                                                                                                                                                    █
█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████

My new malware!
Epilepsy and hearing damage warning!
OS support: Possibly Windows Vista - 11.
Destructive? No.
This is probably one of the best projects I've ever made!
Beta testers: Marlon2210 (thanks for testing the second beta!)
Credits to ChatGPT for teaching me how to use radius and color pallette, also I'm making better shaders now!
Credits to RaduMinecraft, but this user didn't really helped me, but I modified the code from Retrophilia.exe and make the final shader.

N17Pro3426, Vexify, Marlon2210, ComiDaIcIcon (Comium92), Tubercomiosis99 (Sensist2011Cringe), cesiumxx (Mr. Super Buddy), ExpertWorks4417, Aung208, A Russian Guy, RaduMinecraft, Jern216, pankoza, fr4ctalz, PankozaTrojans, pankoza3, kapi2.0peys, Minhgotuknight19 (Tromiute), Kapi2.5peys archive, Vistamations, the_xj (Abyss Guardian), yedb0y33k and WinMalware, if you're reading this, then hi :)

I'm try to add more later.

Anyways, good luck!