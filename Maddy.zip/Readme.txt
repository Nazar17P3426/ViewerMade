Maddy.exe
My new malware!

Note: This is the recreation of Maddy.exe made with Scratch.mit.edu by leotcs39
Here is the link to the Scratch project: https://scratch.mit.edu/projects/1017311969/