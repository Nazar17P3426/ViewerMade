______   ______  _______  aaaa   mmm     mmm _____ nnn   nnn eeeeee
| ____\  | ____|   | |   a    a  | |m   m| |  | |  n na  n n e
| |  | \ | |___    | |   aaaaaa  | | m m | |  | |  n n a n n eeeee
| |__| | | |___    | |   a    a  | |  m  | |  | |  n n  an n e
|_____/  |_|___|   |_|   a    a  mmm     mmm _|_|_ nnn   nnn eeeeee

Comeback, yay!
-----------------------------------------------
Created on: C++
Thanks to N17Pro3426 for some payloads
-----------------------------------------------
Warning!
Running non-peaceful version, it can destroy your computer