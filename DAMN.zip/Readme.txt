-DAMN.exe-

It's joke prank virus, but we are not responsible for any damage caused by this software
It's all your self responsibility

If you want quit this virus, click "want to quit this? click here" link or do taskkill (use taskmgr or cmd)

Coded by NEKOTONKATU
Language: C#