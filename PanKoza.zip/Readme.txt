EN: Don't run this on your real PC!

PL: Nie uruchamiaj tego na prawdziwym komputerze!