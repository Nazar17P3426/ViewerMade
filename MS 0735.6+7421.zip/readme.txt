MS 0735.6+7421.exe by pankoza
C++ GDI Malware
Works in Windows XP-11
This is very dangerous for the non-safety version
The Non-safety version will damage the MBR and make the PC unusable
I'm NOT responsible for any damages
Credits to:
VortexGTX/EthernalVortex - PRGBQUAD
Void_/GetMBR - Hue function

Creation date: 10 February 2023
Note: This is probably my last malware

I named this malware after: https://en.wikipedia.org/wiki/MS_0735.6%2B7421