elevatium by @mrsuperbuddy8216
-------------------------------
Created on: c++

This is very destructive for your computer, please don't run the non-peaceful version