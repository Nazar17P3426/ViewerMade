TrythedoorSonic.exe

Note:
Try the door, Sonic, please try it :(

Date created: 12/7/2023

Scroll or go down more on this reading to continue





































I think this looks like a leak of pankoza's malware for some payloads.
also the 2 last payloads are made of combination of GradientFill with
SRCINVERT BitBlt, a payload before the 2 last payloads, it has the
combination of AlphaBend blur with GradientFill