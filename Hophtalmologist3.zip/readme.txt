Questions:
you can ask me a question about this malware by commenting on https://www.youtube.com/watch?v=EUwWDzGezoA
you don't need to ask me about the date created or the destruction.

Note:
this malware is in beta version, you can only ask soheil shahrab, this is not destructive and it's safe, but also
legendary as Blue.exe and Conductive.exe. so you know. Hi, fr4ctalz and pankoza, Mr. Super Buddy and
N17Pro3426 (Nazar), if you see this on this video, reply to it immediately! if you don't know what to comment
then type "idk" if you see it, hi, I can't make PRGBTRIPLE, blur, GradientFill, please tell in your comments what
linker do I needed to add to my project to make it work?

Answer here:

Information:

Destructive: False

Duration:

0.7 version: 3 ninutes
0.8 version: 6 minutes
0.9 version: I don't know, but you can ask me in description.
1.0 version: 10 minutes

Testable: True (anywhere you want execpt for PC's that have below 1GB RAM.)

Date created:
0.7 version: 10/4/2023
0.8 version: 10/15/2023
0.9 version: 10/17/2023
1.0 version: I don't know

Similar malwares: Krypton.exe, Getaparane.exe (viewer made malware / similar to the fifth payload of my malware)

Warning:
The sounds are loud and there's too much shaders,
so, if you have weak PC or eplipsy, please don't run it
otherwise your computer (if it's weak) or you will be in danger


