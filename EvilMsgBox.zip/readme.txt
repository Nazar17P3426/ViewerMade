EvilMsgBox.exe (long malware)

This malware was made by soheil shahrab, why I didn't know all of my malwares were able to run on
Windows XP, now I know it, unlike Kapi2.0Peys.exe, it dosen't contain quizes until I add a C# to C++ code.
Also, here is the source code for you :)
---------------------------------------------------------------------------------------------------------------------------------
Compatibility required: Windows XP or above

Creation date:
Version 1.0: 3/19/2024

Destructive: No

Payloads:
Version 1.0: Long as Blue.exe, but only the 2 last payloads have 60 seconds

Message boxes:
Warnings: 1
Ask: 1
Annoying or cursed: 5
---------------------------------------------------------------------------------------------------------------------------------
Reason that I can't make destructive version:

1. I am scared that it I will accdientally run it and then it will kill my computer.
2. I don't want to damage anyone's computer
---------------------------------------------------------------------------------------------------------------------------------
Credits to pankoza for the GDI effects
Credits to PortablePoreclain for the final payload bytebeat
Credits to Chasyxx for the second final payload bytebeat