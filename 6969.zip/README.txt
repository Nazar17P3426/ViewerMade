File name: 6969.exe
Creator: Kris The Red Panda (on YouTube)
Creation date: 13/12/2023
==============================================
This program contains malicious code, so, do
not run it on your real computer, only on a virtual
machine.