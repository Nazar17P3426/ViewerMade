﻿╔══════════════════════════════════════════════════════════╗
║Urtierdetierthyruidertdsoddiumpropodideiooris 24670285.exe║
╚══════════════════════════════════════════════════════════╝
It's destructive? No.
Compatibility: Windows 7 and newer
Payloads: 6
Seizure warning!
Time to make: Around 1 hour.
Creation date: 04/04/2024
Thanks for testing!
═══════════════════════════════════════════════
Warning: this malware can mess with your system!