this is a safety malware
rating: 5/10
creator: that kid 101

credits to TheMalwareDev for the bytebeat function
you may need Windows Media Player to set up when and python with pywin32 
works best on Windows 10 and 11
don't run the malware as administrator