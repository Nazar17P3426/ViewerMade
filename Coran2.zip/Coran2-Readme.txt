 _________                                  __________
/   _____ \                                /   _____  \
|  /     \/                                |__/     \  \
|  |       _____  ______  ______  __ ____            | |
|  |      /  _  \/  ___ \<____  \/  '__  \   _______/  |
|  \_____/\ (_)  | /   \//  __   |  /  \  | /  ________/
\_________/\____/|_|     \______/|__|  |__| | |_________
                                            \___________|
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
|_______/                                     \__________|
|          "Be careful from these entities!"             |
|            "You need to find an escape"                |
|  "Say HI to your roomates inside this silver castle!"  |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Password: 2137

Hello again, and im reminding you that this malware is 
dangerous that will delete some system files and over-
write your Bootloader. 

This malware is for educational purposes only! You can
only run this on Virtual Machine.

This malware is created using C++, this take only 6 
days to make while im developing "gl-nummernschild.exe"
which can trigger its payloads on specific dates.
Also the creator (GetMbr) is not any responsible to make
any known changes or damages made to this computer.

Remember:
 + README and ascii of this readme also created by himself (GetMbr).
 + Do not run this on real machine.
 + This is for educational purposes only!
 + Do not skid, if the src code was released by the author (GetMbr).
 
*********************************************************
Accounts:
  1. Discord:
    1. GetMbr#2137
    2. Coran (GetMbr)#2137
    3. Ankha (GetMbr)#2137
  2. Reddit: https://reddit.com/u/GetMbr
********************************************************

The src of this malware will be published soon.
NOTE: Do not skid, because skidding is bad, malware dev-
eloper like me will be hated you if you do it.

Skid means a unskilled programmer, they want to steal
codes intead of learning any programming langauges.