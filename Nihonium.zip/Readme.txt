Nihonium.exe
My second ever malware with 6 payloads!
Destructive: No
Malware length: 3 minutes
Please do NOT run this on an old CRT monitor, since it can cause screen burns.
Seizure & earrape warning!
Made in: C++
Thanks to ChatGPT for helping me to fix GDI errors.
The rest is made by myself.
I'm NOT responsible for ANY screen damages from this malware.
This malware is a half-skidded though.
Feel free to skid anything you like! :)
Thanks for reading!
Bye bye!


-Pawin Vechanon