Nihonium.exe

My second GDI malware!
Seizure and earrape warning!

The rest is made by myself.
I'm not responsible for any damages from this malware.
This malware is a half-skidded through.
Feel free to skid anything you like! :)

Also, thanks to ChatGPT for fixing errors in the codes.

Thanks for reading!

-Pawin Vechanon