Kapi2.0Peys - harmless trojan

This trojan is made on 3/12/2024, with really cool effects and sure you can use them
I really worked hard on the gradient cube and the quiz menu and converting the C# things into C++
Acutally, this is what you call great effects :)

Credits to pankoza/fr4ctalz for gradientfill
Credits to kapi2.0peys for some of its gdi effect (they were C# but i managed to turn it into c++ codes)
Credits to pankoza for rgbquad



ONLY for N17Pro3426
  |
\ /
It contains math quizes, so, if you want to understand, then let me tell you an hint for it

Is 33 + 74 equals 107?
Click Yes, if the answer is 107
Click No, if it's not the answer

Example: (for N17Pro3426)
Is 20 + 60 equals 85?
Write your answer -->