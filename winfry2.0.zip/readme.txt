www  www  www _______ nnnn   nnn _________ ________  yyy  yyy
www  www  www   | |   nnn n  nnn |         |      |  yyy  yyy
www  www  www   | |   nnn  n nnn -------   |      |   yyyyyyy
www  www  www   | |   nnn   nnnn |         --------       yyy
 wwwwwwwwwww  _______ nnn    nnn |         | |    \\ yyyyyyy  2.0!

Creator: Mr. Super Buddy (YouTube: https://youtube.com/@mrsuperbuddy8216)
Language: C++
What's new: new and brutal payloads!

WARNING!
This is a considered malware, so if you running winfry2.0 with the peaceful branch, you'll be safe.