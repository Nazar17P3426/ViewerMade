██████╗░███████╗██████╗░██╗░░██╗███████╗██╗░░░░░██╗██╗░░░██╗███╗░░░███╗
██╔══██╗██╔════╝██╔══██╗██║░██╔╝██╔════╝██║░░░░░██║██║░░░██║████╗░████║
██████╦╝█████╗░░██████╔╝█████═╝░█████╗░░██║░░░░░██║██║░░░██║██╔████╔██║
██╔══██╗██╔══╝░░██╔══██╗██╔═██╗░██╔══╝░░██║░░░░░██║██║░░░██║██║╚██╔╝██║
██████╦╝███████╗██║░░██║██║░╚██╗███████╗███████╗██║╚██████╔╝██║░╚═╝░██║
╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝╚══════╝╚═╝░╚═════╝░╚═╝░░░░░╚═╝
Created by Marlon2210 and N17Pro3426
This software is a malware!
It's very dangerous for the non-safety version
The non-safety version will corrupt the MBR
This works ONLY in Windows 7, 8, 8.1, 10 and 11
The GDI effects works properly in Windows 7 without the aero theme
I'm NOT responsible for ANY damages!
Thanks to N17Pro3426 for helping me


















































Hi I am Wynn, GusttMalWare, RainflowBoi, Comium92, N17Pro3426, yedb0y33k, EmmyMalware, pankoza, fr4ctalz, and more!