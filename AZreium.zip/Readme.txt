AZreium.exe

A solaris remake I made for azrol!
Works best on Windows XP.

It's skidded and safety.