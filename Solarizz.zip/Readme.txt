░██████╗░█████╗░██╗░░░░░░█████╗░██████╗░██╗███████╗███████╗
██╔════╝██╔══██╗██║░░░░░██╔══██╗██╔══██╗██║╚════██║╚════██║
╚█████╗░██║░░██║██║░░░░░███████║██████╔╝██║░░███╔═╝░░███╔═╝
░╚═══██╗██║░░██║██║░░░░░██╔══██║██╔══██╗██║██╔══╝░░██╔══╝░░
██████╔╝╚█████╔╝███████╗██║░░██║██║░░██║██║███████╗███████╗
╚═════╝░░╚════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚══════╝╚══════╝

Created by Marlon2210
Programming language: C++
Destructive : Yes!
This is NOT Solaris lmfao
The non-safety version will destroy this computer
I'm NOT responsible for ANY damages
Works in Windows Vista, 7, 8, 8.1, 10 and 11




























































































































Hi N17Pro3426, MrDoge877, pankoza, GusttMalWare, I am Wynn, yedb0y33k, Comium92, fr4ctalz, RainflowBoi, and more!