MS0735.6+7421.exe by pankoza
C++ GDI Malware
Works in Windows XP-11
This is very dangerous for the non-safety version
The Non-safety version will damage the MBR and make the PC unusable
I'm NOT Responsible for any damages
Credits to:
VortexGTX/EthernalVortex - PRGBQUAD
Void_/GetMBR - Hue Function

Creation date: 10 Feb 2023
note: This is probably my last malware

i named this malware after: https://en.wikipedia.org/wiki/MS_0735.6%2B7421