████████████████████████████████████
█─█─█▄─▄▄─█▄─▄███▄─▄█▄─██─▄█▄─▀█▀─▄█
█─▄─██─▄█▀██─██▀██─███─██─███─█▄█─██
▀▄▀▄▀▄▄▄▄▄▀▄▄▄▄▄▀▄▄▄▀▀▄▄▄▄▀▀▄▄▄▀▄▄▄▀

Helium.exe
A GDI safety trojan made by Tubercomiosis99
Epilepsy warning.
It has the bytebeats again.

"It's really skidded?"
I left a comment in the source code.