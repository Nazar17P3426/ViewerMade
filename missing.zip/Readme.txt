   -=- missing.exe -=-

*-----------------------------------------------------------------------------*
Description :

The safety version of missing.exe
can be run on the actual device. Note that the dangerous version may not work properly unless it is run on VMware.
Also, this malware is very sensitive, so if you are able to log in after running the dangerous version,
there may be a bug in the malware.

Payload :
Warning > GDI > logonUI overwrite > Error if logonUI repaired > MBR overwrite
*-----------------------------------------------------------------------------*
説明 :

missing.exeはsafetyバージョンは実機でも実行できます。
ちなみに危険版はVMwareで実行しないとうまく動作しない可能性があります。
また、このマルウェアは動作が思いたいためもし危険バージョンを実行してもログインができてしまったらバグが起きているかもしれません

ペイロード :
警告 > GDI > logonUI上書き > logonUIを修復した場合はエラーが出る > MBR上書き
*-----------------------------------------------------------------------------*

development language : C++
開発言語 : C++

*-----------------------------------------------------------------------------*

x86 = 32bit
x64 = 64bit

*-----------------------------------------------------------------------------*
by NEKOTONKATU