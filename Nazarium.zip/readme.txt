Nazarium.exe (a.k.a. salinewin2.0.exe)
This malware has beatiful RGBQUAD and HSL shaders
Works on Windows XP (idk about Windows 2000) to Windows 11

To skid the effects from this trojan:
1. I should know you and trust you, like Tubercomiosis99
2. Say, why are you want to skid.
3. If N17Pro3426 skid from this trojan without mine permission, you know, what I will do >:(
4. If you broke these rules, I will raid you



































Fun fact: this malware is remake of salinewin.exe