Questions:
you can ask me a question about this malware by commenting on https://www.youtube.com/watch?v=EUwWDzGezoA
don't ask me about download until pankoza comments on my second video -_- but unlike my future and old malwares, it's private.
you don't need to ask me about the date created or the destruction.

Information:

Destructive: False
Duration:

0.7 version: 3 minutes
1.0 version: 10 minutes

Testable: True

Date created:
0.7: 10/4/2023
1.0: I don't know

Similar malwares: Krypton.exe, Getaparane.exe (viewer made malware / for the fifth payload of my malware)

Warning:
The sounds are loud and there's too much shaders,
so, if you have weak PC or eplipsy, please don't run it
otherwise, your computer (if it's weak) or you will be in danger

Note:
this malware is beta version, you can only ask soheil, this is not destructive and its safe but also legendary
as Blue.exe and Conductive.exe. so do you know


