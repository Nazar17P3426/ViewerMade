Read this file completely!

Beware! This file deletes Windows extremely, if you do NOT want
to get critical damage to your computer, just do NOT run this
file. This file is very dangerous. I'm talking you serious.

NO, but without excession, if you have a big balls, you can run
this file on the original computer.

Detection rate: 26/72 - link for detection: https://www.virustotal.com/gui/file/366373109445178df10e219c3d58ea40b435c3cc20f80be7398d199aee01f62b?nocache=1

Also you can check in detect.png file detection rate. I'm not joking!

This file is very brutal! It removes Windows registry settings.
You're running this trojan horse for your own risk!

Probably tested by: CYBER SOLDIER (Clutter), Haxhom