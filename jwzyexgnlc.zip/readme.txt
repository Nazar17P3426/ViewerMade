jwzyexgnlc.exe by pankoza

C++ GDI Malware
This is very dangerous for the non-safety version, the non-safety version will damage the MBR and make the PC unusable
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy!
I'm not responsible for any damages.
Credits to ArTicZera and Wipet for the HSL RGBQUAD
Creation date: July 2 2023
I managed to make a comeback after HorrorKrabs 2.0.exe but This is probably my last malware until I decide to make another comeback