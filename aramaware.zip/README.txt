Hello, it appears as if you have download aramaware.exe. Please be cautious and only use this
file inside of a safe environment such as a virtual machine, and have a snapshot already
loaded previously so you can restore your virtual machines data once it is completely destroyed.
-----------------------------------------------------------------------
This malware has been created by hessfire, and was made specifically for aramaware. 
-----------------------------------------------------------------------
TESTERS: Anyone, as long as you're using a virtual machine.
-----------------------------------------------------------------------
Anyway, stay safe, and have fun with this malware :)

 █████  ██████   █████  ███    ███  █████  ██     ██  █████  ██████  ███████ 
██   ██ ██   ██ ██   ██ ████  ████ ██   ██ ██     ██ ██   ██ ██   ██ ██      
███████ ██████  ███████ ██ ████ ██ ███████ ██  █  ██ ███████ ██████  █████   
██   ██ ██   ██ ██   ██ ██  ██  ██ ██   ██ ██ ███ ██ ██   ██ ██   ██ ██      
██   ██ ██   ██ ██   ██ ██      ██ ██   ██  ███ ███  ██   ██ ██   ██ ███████ 

                                                      
                                                      
█████ █████ █████ █████ █████ █████ █████ █████ █████ 
                                                      
                                                      
                                                      
                                                                                                                                   
                                                                 
                                                      

                                                      
                                                      
                                                      
                                                                                                                        