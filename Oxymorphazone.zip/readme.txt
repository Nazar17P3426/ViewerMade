Oxymorphazone.exe by pankoza
Yet another 20 payload malware
Created on: October 30 2023 (Halloween Eve)
The non-safety version has a lot of destructive potential, so run it only in a virtual machine
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy or other similar medical conditions
Credits to ArTicZera and Wipet for the HSL
Credits to GetMBR for the Hue function
Credits to EthernalVortex for PRGBQUAD
Huge thanks to fr4ctalz for the bouncing rotating triangle, melt, random icons, and opaque HSL code
Credits to N17Pro3426 for some bytebeats, radius and the fast waving codes
If you want to run it on Windows XP/Server 2003 x64 Edition, then use the x64 version or it won't set itself as critical process


























































Hi fr4ctalz, N17Pro3426, Crypto NWO and RainflowBoi, if you are reading this, hi.
Also, I can't believe it's almost the end of the year!