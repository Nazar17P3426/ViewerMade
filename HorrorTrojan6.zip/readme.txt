Hello, and welcome to HorrorTrojan 6.66! This is probably the final version of HorrorTrojan that i will ever make. 
It's not as destructive and will not your pc unbootable but it loops itself on startup and disables task manager so run it only on vm.
The Source is included in the zip so have fun!