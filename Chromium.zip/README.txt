Thanks for reading this note.

I assume you wanted to install Chromium.exe. Before you run
it, please run this in a Virtual Machine, the creator will NOT be
responsible for ANY damage caused by this trojan.

If you're epileptic, don't run this, you will have a seizure from
flashing lights!

By running the destructive version of Chromium.exe and
agreeing to the warnings, the MBR is already overwritten
before the GDI payloads end, when the payloads end the system
will reboot.

An MBR (Master Boot Record) tells the computer to boot up
(start). If it's overwritten, it will display a black screen.

If you want ANY help, dm in Discord: voiddragon4191
If you want ANY help, tag me on YouTube: @voiddragon4191

If you read everything and you agreed, you can run the trojan.