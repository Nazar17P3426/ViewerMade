Phobos horror malware by The Malware Unity.
===========================================================
Hello! This malware is made by The Malware Unity team!
We planned to make Phobos be another effects malware...
But we thought: "GDI is boring. Everyone can do them!",
And created the current Phobos which is a horror malware.
We really hope you like it! Good luck testing!
Made by these people: HellKnight, Khonsu, Blazer, Nywal.
===========================================================
Привет! Этот троян создан командой The Malware Unity!
Мы хотели сделать Phobos еще одним трояном с эффектами...
Но мы подумали: «GDI скучный. Такие может делать каждый!»,
И создали этот Phobos, который является хоррор вирусом.
Мы очень надеемся, что вам понравится! Удачи!
А вот и создатели: HellKnight, Khonsu, Blazer, Nywal.
===========================================================
This trojan is destructive. Rename to .exe before running.
===========================================================
Этот троян деструктивный. При запуске переименуйте в .exe.
===========================================================
OS Support: Windows 95 / 98 - Windows 11.
===========================================================